import { describe, expect, it } from "vitest";
import {
  KEYBOARD_NOTE_MAP,
  getMappedNote,
  getOctaveFromKey,
} from "../lib/keyboard-mapping";

describe("keyboard support", () => {
  it("maps the chromatic QWERTY layout across one octave", () => {
    expect(Object.keys(KEYBOARD_NOTE_MAP)).toHaveLength(12);
    expect("awsedftgyhuj".split("").map(getMappedNote)).toEqual([
      "C",
      "C#",
      "D",
      "D#",
      "E",
      "F",
      "F#",
      "G",
      "G#",
      "A",
      "A#",
      "B",
    ]);
  });

  it("accepts uppercase input and ignores unmapped keys", () => {
    expect(getMappedNote("A")).toBe("C");
    expect(getMappedNote(" ")).toBeUndefined();
    expect(getMappedNote("Enter")).toBeUndefined();
  });

  it("converts direct numeric octave shortcuts without accepting invalid keys", () => {
    expect(getOctaveFromKey("0")).toBe(0);
    expect(getOctaveFromKey("9")).toBe(9);
    expect(getOctaveFromKey("10")).toBeNull();
    expect(getOctaveFromKey("[")).toBeNull();
  });
});
