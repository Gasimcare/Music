import { describe, expect, it } from "vitest";
import { readFileSync, statSync } from "node:fs";
import { resolve } from "node:path";

describe("bundled default skin", () => {
  it("is packaged as a non-empty Skin asset", () => {
    const skinPath = resolve(process.cwd(), "assets/skins/default.Skin");
    expect(statSync(skinPath).isFile()).toBe(true);
    expect(readFileSync(skinPath, "utf8")).toBe("; ORG Skin file");
  });

  it("includes the Standard25Key model asset", () => {
    const modelPath = resolve(process.cwd(), "assets/models/Standard25Key.Model");
    expect(statSync(modelPath).isFile()).toBe(true);
    expect(readFileSync(modelPath, "utf8")).toContain("Name: Standard 25 Key");
  });

  it("includes the Normal.System binary asset", () => {
    const systemPath = resolve(process.cwd(), "assets/system/Normal.System");
    expect(statSync(systemPath).isFile()).toBe(true);
    expect(readFileSync(systemPath).subarray(0, 32).toString("ascii")).toContain("Music Studio System");
  });
});
