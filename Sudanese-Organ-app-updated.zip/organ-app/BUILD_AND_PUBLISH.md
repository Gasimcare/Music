# دليل البناء والنشر السريع - Sudanese Organ

## الخطوات السريعة للنشر على Google Play Store

### الخطوة 1: إعداد البيئة

```bash
# تثبيت المتطلبات
npm install -g expo-cli eas-cli

# تسجيل الدخول إلى Expo
expo login

# أو استخدام EAS CLI
eas login
```

### الخطوة 2: إعداد ملف `eas.json`

تأكد من وجود ملف `eas.json` في جذر المشروع:

```json
{
  "build": {
    "preview": {
      "android": {
        "buildType": "apk"
      }
    },
    "preview2": {
      "android": {
        "buildType": "apk"
      }
    },
    "preview3": {
      "android": {
        "buildType": "apk"
      }
    },
    "production": {
      "android": {
        "buildType": "aab"
      }
    }
  }
}
```

### الخطوة 3: بناء APK للاختبار

```bash
# بناء APK للاختبار
eas build --platform android --profile preview

# أو بناء AAB للإنتاج
eas build --platform android --profile production
```

### الخطوة 4: تحميل على Google Play Store

1. اذهب إلى [Google Play Console](https://play.google.com/console)
2. اختر التطبيق "Sudanese Organ"
3. اذهب إلى "الإصدار" → "الإنتاج"
4. انقر على "إنشاء إصدار جديد"
5. اختر ملف AAB الذي تم بناؤه
6. أضف ملاحظات الإصدار
7. انقر على "مراجعة" ثم "نشر"

---

## معلومات التطبيق

| المعلومة | القيمة |
|---------|--------|
| **اسم التطبيق** | Sudanese Organ |
| **Package Name** | space.manus.sudanese.organ |
| **الإصدار** | 1.0.0 |
| **الفئة** | الموسيقى |
| **التصنيف العمري** | للجميع |

---

## الملفات المطلوبة

- ✅ `app.config.ts` - معلومات التطبيق
- ✅ `eas.json` - إعدادات البناء
- ✅ `assets/images/icon.png` - أيقونة التطبيق
- ✅ `package.json` - المتطلبات والمكتبات

---

## التحقق قبل النشر

- [ ] اختبار التطبيق على أجهزة حقيقية
- [ ] التحقق من جميع الميزات
- [ ] اختبار الأصوات والتأثيرات
- [ ] التحقق من الإعدادات
- [ ] اختبار الأداء

---

## الدعم والمراجع

- [Expo Build Documentation](https://docs.expo.dev/build/setup/)
- [Google Play Console Help](https://support.google.com/googleplay)
- [Android App Bundle Guide](https://developer.android.com/guide/app-bundle)

---

**آخر تحديث:** 10 يوليو 2026
