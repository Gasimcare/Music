/**
 * نظام التأثيرات الصوتية المتقدمة
 * يتضمن Sustain, Reverb, Delay وتأثيرات أخرى
 */

export interface AudioEffectsConfig {
  sustain: number; // 0-1
  reverb: number; // 0-1
  delay: number; // 0-1
  delayTime: number; // بالثواني
  delayFeedback: number; // 0-1
}

export class AudioEffectsProcessor {
  private audioContext: AudioContext | null = null;
  private sustainNodes: Map<string, SustainNode> = new Map();
  private reverbNode: ConvolverNode | null = null;
  private delayNodes: Map<string, DelayNode> = new Map();
  private dryGain: GainNode | null = null;
  private wetGain: GainNode | null = null;
  private config: AudioEffectsConfig;

  constructor(audioContext: AudioContext | null, config: AudioEffectsConfig) {
    this.audioContext = audioContext;
    this.config = config;
    if (audioContext) {
      this.initializeEffects();
    }
  }

  private initializeEffects(): void {
    if (!this.audioContext) return;

    // إنشاء عقد الكسب للإشارات الجافة والرطبة
    this.dryGain = this.audioContext.createGain();
    this.wetGain = this.audioContext.createGain();

    // تحديث مستويات الكسب بناءً على الإعدادات
    this.updateEffectLevels();

    // إنشاء Reverb (Convolver)
    this.createReverbEffect();
  }

  private createReverbEffect(): void {
    if (!this.audioContext || !this.wetGain) return;

    this.reverbNode = this.audioContext.createConvolver();

    // إنشاء impulse response بسيط للصدى
    const rate = this.audioContext.sampleRate;
    const length = rate * 2; // ثانيتان من الصدى
    const impulse = this.audioContext.createBuffer(2, length, rate);
    const left = impulse.getChannelData(0);
    const right = impulse.getChannelData(1);

    // ملء البيانات بقيم عشوائية متناقصة (محاكاة الصدى)
    for (let i = 0; i < length; i++) {
      left[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, 2);
      right[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, 2);
    }

    this.reverbNode.buffer = impulse;
    this.reverbNode.connect(this.wetGain);
  }

  /**
   * تطبيق تأثير Sustain على نغمة
   */
  public applySustain(
    oscillator: OscillatorNode,
    gainNode: GainNode,
    noteFrequency: number,
    sustainAmount: number
  ): void {
    if (!this.audioContext) return;

    const sustainNode: SustainNode = {
      oscillator,
      gainNode,
      sustainAmount,
      startTime: this.audioContext.currentTime,
      isActive: true,
    };

    // تطبيق تأثير Sustain بزيادة مدة الصوت
    const sustainDuration = sustainAmount * 3; // حتى 3 ثوان إضافية
    gainNode.gain.setValueAtTime(gainNode.gain.value, this.audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(
      gainNode.gain.value * 0.7,
      this.audioContext.currentTime + sustainDuration
    );

    this.sustainNodes.set(`${noteFrequency}-${this.audioContext.currentTime}`, sustainNode);
  }

  /**
   * تطبيق تأثير Reverb على الصوت
   */
  public applyReverb(
    sourceNode: GainNode,
    reverbAmount: number
  ): GainNode | null {
    if (!this.audioContext || !this.reverbNode || !this.wetGain || !this.dryGain) {
      return null;
    }

    // توصيل المصدر إلى كل من الإشارات الجافة والرطبة
    sourceNode.connect(this.dryGain);
    sourceNode.connect(this.reverbNode);

    // تحديث مستويات الكسب
    this.dryGain.gain.value = 1 - reverbAmount * 0.5;
    this.wetGain.gain.value = reverbAmount * 0.3;

    return this.wetGain;
  }

  /**
   * تطبيق تأثير Delay على الصوت
   */
  public applyDelay(
    sourceNode: GainNode,
    delayTime: number = 0.5,
    feedback: number = 0.4,
    delayAmount: number = 0.3
  ): DelayNode | null {
    if (!this.audioContext) return null;

    const delayNode = this.audioContext.createDelay(5);
    const feedbackGain = this.audioContext.createGain();
    const dryGain = this.audioContext.createGain();
    const wetGain = this.audioContext.createGain();

    // إعداد Delay
    delayNode.delayTime.value = delayTime;
    feedbackGain.gain.value = feedback;
    dryGain.gain.value = 1 - delayAmount;
    wetGain.gain.value = delayAmount;

    // توصيل العقد
    sourceNode.connect(dryGain);
    sourceNode.connect(delayNode);
    delayNode.connect(feedbackGain);
    feedbackGain.connect(delayNode);
    delayNode.connect(wetGain);

    // توصيل الإخراج
    if (this.audioContext.destination) {
      dryGain.connect(this.audioContext.destination);
      wetGain.connect(this.audioContext.destination);
    }

    this.delayNodes.set(`delay-${Date.now()}`, delayNode);
    return delayNode;
  }

  /**
   * تحديث مستويات التأثيرات
   */
  public updateEffectLevels(): void {
    if (!this.dryGain || !this.wetGain) return;

    const totalEffect = this.config.reverb + this.config.delay;
    this.dryGain.gain.value = Math.max(0.3, 1 - totalEffect * 0.5);
    this.wetGain.gain.value = (this.config.reverb * 0.3 + this.config.delay * 0.2) / 2;
  }

  /**
   * تحديث إعدادات التأثيرات
   */
  public updateConfig(config: Partial<AudioEffectsConfig>): void {
    this.config = { ...this.config, ...config };
    this.updateEffectLevels();
  }

  /**
   * إيقاف جميع التأثيرات
   */
  public stopAllEffects(): void {
    this.sustainNodes.forEach((node) => {
      node.isActive = false;
    });
    this.sustainNodes.clear();

    this.delayNodes.forEach((delayNode) => {
      try {
        delayNode.disconnect();
      } catch (e) {
        // قد يكون العقدة قد قطعت بالفعل
      }
    });
    this.delayNodes.clear();
  }

  /**
   * الحصول على عقدة Reverb
   */
  public getReverbNode(): ConvolverNode | null {
    return this.reverbNode;
  }

  /**
   * الحصول على عقدة الكسب الرطبة
   */
  public getWetGain(): GainNode | null {
    return this.wetGain;
  }

  /**
   * الحصول على عقدة الكسب الجافة
   */
  public getDryGain(): GainNode | null {
    return this.dryGain;
  }
}

/**
 * واجهة عقدة Sustain
 */
interface SustainNode {
  oscillator: OscillatorNode;
  gainNode: GainNode;
  sustainAmount: number;
  startTime: number;
  isActive: boolean;
}

/**
 * واجهة عقدة Delay
 */
interface DelayNode {
  delayTime: AudioParam;
  disconnect: () => void;
}
