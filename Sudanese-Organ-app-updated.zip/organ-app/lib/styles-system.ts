/**
 * نظام إدارة الأنماط الموسيقية (Styles)
 * يدعم تحميل وتشغيل أنماط موسيقية متعددة
 */

export interface MusicStyle {
  id: string;
  name: string;
  category: string;
  description: string;
  bpm: number;
  timeSignature: string;
  instruments: string[];
  audioUrl?: string;
  previewUrl?: string;
  tags: string[];
  rating: number;
  downloads: number;
  createdBy: string;
  createdDate: Date;
}

export interface StyleCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  styles: MusicStyle[];
}

export class StylesSystem {
  private styles: Map<string, MusicStyle> = new Map();
  private categories: Map<string, StyleCategory> = new Map();
  private favorites: Set<string> = new Set();
  private currentStyle: MusicStyle | null = null;

  /**
   * إضافة نمط موسيقي جديد
   */
  addStyle(style: MusicStyle): void {
    this.styles.set(style.id, style);
  }

  /**
   * الحصول على نمط موسيقي
   */
  getStyle(id: string): MusicStyle | undefined {
    return this.styles.get(id);
  }

  /**
   * البحث عن أنماط موسيقية
   */
  searchStyles(query: string): MusicStyle[] {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.styles.values()).filter(
      (style) =>
        style.name.toLowerCase().includes(lowerQuery) ||
        style.description.toLowerCase().includes(lowerQuery) ||
        style.tags.some((tag) => tag.toLowerCase().includes(lowerQuery))
    );
  }

  /**
   * الحصول على الأنماط حسب الفئة
   */
  getStylesByCategory(categoryId: string): MusicStyle[] {
    return Array.from(this.styles.values()).filter(
      (style) => style.category === categoryId
    );
  }

  /**
   * تعيين النمط الحالي
   */
  setCurrentStyle(styleId: string): boolean {
    const style = this.styles.get(styleId);
    if (style) {
      this.currentStyle = style;
      return true;
    }
    return false;
  }

  /**
   * الحصول على النمط الحالي
   */
  getCurrentStyle(): MusicStyle | null {
    return this.currentStyle;
  }

  /**
   * إضافة نمط إلى المفضلة
   */
  addToFavorites(styleId: string): void {
    if (this.styles.has(styleId)) {
      this.favorites.add(styleId);
    }
  }

  /**
   * إزالة نمط من المفضلة
   */
  removeFromFavorites(styleId: string): void {
    this.favorites.delete(styleId);
  }

  /**
   * الحصول على المفضلة
   */
  getFavorites(): MusicStyle[] {
    return Array.from(this.favorites)
      .map((id) => this.styles.get(id))
      .filter((style) => style !== undefined) as MusicStyle[];
  }

  /**
   * التحقق من كون النمط مفضلاً
   */
  isFavorite(styleId: string): boolean {
    return this.favorites.has(styleId);
  }

  /**
   * الحصول على أفضل الأنماط (حسب التقييم)
   */
  getTopStyles(limit: number = 10): MusicStyle[] {
    return Array.from(this.styles.values())
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }

  /**
   * الحصول على الأنماط الأكثر تحميلاً
   */
  getMostDownloaded(limit: number = 10): MusicStyle[] {
    return Array.from(this.styles.values())
      .sort((a, b) => b.downloads - a.downloads)
      .slice(0, limit);
  }

  /**
   * إضافة فئة جديدة
   */
  addCategory(category: StyleCategory): void {
    this.categories.set(category.id, category);
  }

  /**
   * الحصول على جميع الفئات
   */
  getCategories(): StyleCategory[] {
    return Array.from(this.categories.values());
  }

  /**
   * تحديث تقييم النمط
   */
  updateStyleRating(styleId: string, newRating: number): void {
    const style = this.styles.get(styleId);
    if (style) {
      style.rating = Math.min(5, Math.max(0, newRating));
    }
  }

  /**
   * زيادة عدد التحميلات
   */
  incrementDownloads(styleId: string): void {
    const style = this.styles.get(styleId);
    if (style) {
      style.downloads += 1;
    }
  }

  /**
   * الحصول على إحصائيات الأنماط
   */
  getStatistics(): {
    totalStyles: number;
    totalCategories: number;
    totalFavorites: number;
    averageRating: number;
  } {
    const styles = Array.from(this.styles.values());
    const averageRating =
      styles.length > 0
        ? styles.reduce((sum, style) => sum + style.rating, 0) / styles.length
        : 0;

    return {
      totalStyles: this.styles.size,
      totalCategories: this.categories.size,
      totalFavorites: this.favorites.size,
      averageRating,
    };
  }

  /**
   * تصدير الأنماط كـ JSON
   */
  exportStyles(): string {
    return JSON.stringify(
      {
        styles: Array.from(this.styles.values()),
        categories: Array.from(this.categories.values()),
        favorites: Array.from(this.favorites),
      },
      null,
      2
    );
  }

  /**
   * استيراد الأنماط من JSON
   */
  importStyles(jsonData: string): void {
    try {
      const data = JSON.parse(jsonData);
      if (data.styles) {
        data.styles.forEach((style: MusicStyle) => {
          this.addStyle(style);
        });
      }
      if (data.categories) {
        data.categories.forEach((category: StyleCategory) => {
          this.addCategory(category);
        });
      }
      if (data.favorites) {
        data.favorites.forEach((id: string) => {
          this.favorites.add(id);
        });
      }
    } catch (error) {
      console.error("Error importing styles:", error);
    }
  }

  /**
   * مسح جميع البيانات
   */
  clear(): void {
    this.styles.clear();
    this.categories.clear();
    this.favorites.clear();
    this.currentStyle = null;
  }
}

/**
 * مثيل عام من نظام الأنماط
 */
export const stylesSystem = new StylesSystem();

// تحميل الأنماط الافتراضية من Sofeh Sunrise
export const DEFAULT_STYLES: MusicStyle[] = [
  {
    id: "pop-1",
    name: "Modern Pop",
    category: "pop",
    description: "نمط بوب حديث مع إيقاع سريع",
    bpm: 120,
    timeSignature: "4/4",
    instruments: ["drums", "bass", "guitar", "keyboard"],
    tags: ["pop", "modern", "upbeat"],
    rating: 4.5,
    downloads: 1200,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
  },
  {
    id: "arabic-1",
    name: "Arabic Classic",
    category: "arabic",
    description: "نمط عربي كلاسيكي تقليدي",
    bpm: 100,
    timeSignature: "4/4",
    instruments: ["oud", "ney", "qanun", "drums"],
    tags: ["arabic", "classic", "traditional"],
    rating: 4.8,
    downloads: 2500,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
  },
  {
    id: "jazz-1",
    name: "Smooth Jazz",
    category: "jazz",
    description: "جاز ناعم مع بيانو وساكسفون",
    bpm: 90,
    timeSignature: "4/4",
    instruments: ["piano", "saxophone", "bass", "drums"],
    tags: ["jazz", "smooth", "relaxing"],
    rating: 4.6,
    downloads: 1800,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
  },
  {
    id: "dance-1",
    name: "Electronic Dance",
    category: "dance",
    description: "موسيقى رقص إلكترونية حديثة",
    bpm: 130,
    timeSignature: "4/4",
    instruments: ["synth", "drums", "bass"],
    tags: ["dance", "electronic", "energetic"],
    rating: 4.3,
    downloads: 1500,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
  },
];

// تحميل الأنماط الافتراضية
DEFAULT_STYLES.forEach((style) => stylesSystem.addStyle(style));
