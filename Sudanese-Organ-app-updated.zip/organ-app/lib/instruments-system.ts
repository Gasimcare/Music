/**
 * نظام إدارة الآلات الموسيقية (Instruments)
 * يدعم تحميل وتشغيل آلات موسيقية متعددة
 */

export interface Instrument {
  id: string;
  name: string;
  category: string;
  description: string;
  frequency: number;
  soundUrl?: string;
  previewUrl?: string;
  tags: string[];
  rating: number;
  downloads: number;
  createdBy: string;
  createdDate: Date;
  properties: {
    attack: number;
    decay: number;
    sustain: number;
    release: number;
  };
}

export interface InstrumentCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  instruments: Instrument[];
}

export class InstrumentsSystem {
  private instruments: Map<string, Instrument> = new Map();
  private categories: Map<string, InstrumentCategory> = new Map();
  private favorites: Set<string> = new Set();
  private currentInstrument: Instrument | null = null;

  /**
   * إضافة آلة موسيقية جديدة
   */
  addInstrument(instrument: Instrument): void {
    this.instruments.set(instrument.id, instrument);
  }

  /**
   * الحصول على آلة موسيقية
   */
  getInstrument(id: string): Instrument | undefined {
    return this.instruments.get(id);
  }

  /**
   * البحث عن آلات موسيقية
   */
  searchInstruments(query: string): Instrument[] {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.instruments.values()).filter(
      (instrument) =>
        instrument.name.toLowerCase().includes(lowerQuery) ||
        instrument.description.toLowerCase().includes(lowerQuery) ||
        instrument.tags.some((tag) => tag.toLowerCase().includes(lowerQuery))
    );
  }

  /**
   * الحصول على الآلات حسب الفئة
   */
  getInstrumentsByCategory(categoryId: string): Instrument[] {
    return Array.from(this.instruments.values()).filter(
      (instrument) => instrument.category === categoryId
    );
  }

  /**
   * تعيين الآلة الحالية
   */
  setCurrentInstrument(instrumentId: string): boolean {
    const instrument = this.instruments.get(instrumentId);
    if (instrument) {
      this.currentInstrument = instrument;
      return true;
    }
    return false;
  }

  /**
   * الحصول على الآلة الحالية
   */
  getCurrentInstrument(): Instrument | null {
    return this.currentInstrument;
  }

  /**
   * إضافة آلة إلى المفضلة
   */
  addToFavorites(instrumentId: string): void {
    if (this.instruments.has(instrumentId)) {
      this.favorites.add(instrumentId);
    }
  }

  /**
   * إزالة آلة من المفضلة
   */
  removeFromFavorites(instrumentId: string): void {
    this.favorites.delete(instrumentId);
  }

  /**
   * الحصول على المفضلة
   */
  getFavorites(): Instrument[] {
    return Array.from(this.favorites)
      .map((id) => this.instruments.get(id))
      .filter((instrument) => instrument !== undefined) as Instrument[];
  }

  /**
   * التحقق من كون الآلة مفضلة
   */
  isFavorite(instrumentId: string): boolean {
    return this.favorites.has(instrumentId);
  }

  /**
   * الحصول على أفضل الآلات (حسب التقييم)
   */
  getTopInstruments(limit: number = 10): Instrument[] {
    return Array.from(this.instruments.values())
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }

  /**
   * الحصول على الآلات الأكثر تحميلاً
   */
  getMostDownloaded(limit: number = 10): Instrument[] {
    return Array.from(this.instruments.values())
      .sort((a, b) => b.downloads - a.downloads)
      .slice(0, limit);
  }

  /**
   * إضافة فئة جديدة
   */
  addCategory(category: InstrumentCategory): void {
    this.categories.set(category.id, category);
  }

  /**
   * الحصول على جميع الفئات
   */
  getCategories(): InstrumentCategory[] {
    return Array.from(this.categories.values());
  }

  /**
   * تحديث تقييم الآلة
   */
  updateInstrumentRating(instrumentId: string, newRating: number): void {
    const instrument = this.instruments.get(instrumentId);
    if (instrument) {
      instrument.rating = Math.min(5, Math.max(0, newRating));
    }
  }

  /**
   * زيادة عدد التحميلات
   */
  incrementDownloads(instrumentId: string): void {
    const instrument = this.instruments.get(instrumentId);
    if (instrument) {
      instrument.downloads += 1;
    }
  }

  /**
   * الحصول على إحصائيات الآلات
   */
  getStatistics(): {
    totalInstruments: number;
    totalCategories: number;
    totalFavorites: number;
    averageRating: number;
  } {
    const instruments = Array.from(this.instruments.values());
    const averageRating =
      instruments.length > 0
        ? instruments.reduce((sum, instrument) => sum + instrument.rating, 0) /
          instruments.length
        : 0;

    return {
      totalInstruments: this.instruments.size,
      totalCategories: this.categories.size,
      totalFavorites: this.favorites.size,
      averageRating,
    };
  }

  /**
   * تصدير الآلات كـ JSON
   */
  exportInstruments(): string {
    return JSON.stringify(
      {
        instruments: Array.from(this.instruments.values()),
        categories: Array.from(this.categories.values()),
        favorites: Array.from(this.favorites),
      },
      null,
      2
    );
  }

  /**
   * استيراد الآلات من JSON
   */
  importInstruments(jsonData: string): void {
    try {
      const data = JSON.parse(jsonData);
      if (data.instruments) {
        data.instruments.forEach((instrument: Instrument) => {
          this.addInstrument(instrument);
        });
      }
      if (data.categories) {
        data.categories.forEach((category: InstrumentCategory) => {
          this.addCategory(category);
        });
      }
      if (data.favorites) {
        data.favorites.forEach((id: string) => {
          this.favorites.add(id);
        });
      }
    } catch (error) {
      console.error("Error importing instruments:", error);
    }
  }

  /**
   * مسح جميع البيانات
   */
  clear(): void {
    this.instruments.clear();
    this.categories.clear();
    this.favorites.clear();
    this.currentInstrument = null;
  }
}

/**
 * مثيل عام من نظام الآلات
 */
export const instrumentsSystem = new InstrumentsSystem();

// تحميل الآلات الافتراضية من Sofeh Sunrise
export const DEFAULT_INSTRUMENTS: Instrument[] = [
  {
    id: "piano-1",
    name: "Grand Piano",
    category: "piano",
    description: "بيانو كبير احترافي",
    frequency: 440,
    tags: ["piano", "professional", "acoustic"],
    rating: 4.9,
    downloads: 3500,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
    properties: { attack: 0.05, decay: 0.3, sustain: 0.7, release: 0.5 },
  },
  {
    id: "guitar-1",
    name: "Acoustic Guitar",
    category: "guitar",
    description: "جيتار أكوستي دافئ",
    frequency: 440,
    tags: ["guitar", "acoustic", "warm"],
    rating: 4.7,
    downloads: 2800,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
    properties: { attack: 0.1, decay: 0.4, sustain: 0.5, release: 0.6 },
  },
  {
    id: "violin-1",
    name: "Violin",
    category: "strings",
    description: "كمان كلاسيكي",
    frequency: 440,
    tags: ["violin", "strings", "classical"],
    rating: 4.8,
    downloads: 2200,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
    properties: { attack: 0.15, decay: 0.2, sustain: 0.8, release: 0.4 },
  },
  {
    id: "oud-1",
    name: "Oud",
    category: "arabic",
    description: "عود عربي تقليدي",
    frequency: 440,
    tags: ["oud", "arabic", "traditional"],
    rating: 4.9,
    downloads: 2900,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
    properties: { attack: 0.08, decay: 0.35, sustain: 0.6, release: 0.55 },
  },
  {
    id: "ney-1",
    name: "Ney",
    category: "arabic",
    description: "ناي عربي تقليدي",
    frequency: 440,
    tags: ["ney", "arabic", "wind"],
    rating: 4.6,
    downloads: 1800,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
    properties: { attack: 0.12, decay: 0.25, sustain: 0.75, release: 0.5 },
  },
  {
    id: "drums-1",
    name: "Drums",
    category: "percussion",
    description: "طبول احترافية",
    frequency: 100,
    tags: ["drums", "percussion", "rhythm"],
    rating: 4.5,
    downloads: 2100,
    createdBy: "Sofeh Sunrise",
    createdDate: new Date(),
    properties: { attack: 0.01, decay: 0.2, sustain: 0.1, release: 0.3 },
  },
];

// تحميل الآلات الافتراضية
DEFAULT_INSTRUMENTS.forEach((instrument) =>
  instrumentsSystem.addInstrument(instrument)
);
