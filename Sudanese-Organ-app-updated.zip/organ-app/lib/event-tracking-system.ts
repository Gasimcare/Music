/**
 * نظام تتبع الأحداث المخصص (Event Tracking System)
 * يتابع جميع أحداث استخدام التطبيق
 */

export interface TrackedEvent {
  id: string;
  eventName: string;
  eventType: "key_press" | "recording" | "playback" | "settings" | "navigation" | "error" | "custom";
  timestamp: Date;
  userId?: string;
  sessionId: string;
  data: Record<string, any>;
  duration?: number;
  success: boolean;
}

export interface EventStatistics {
  totalEvents: number;
  eventsByType: Record<string, number>;
  eventsByName: Record<string, number>;
  averageEventDuration: number;
  successRate: number;
  errorRate: number;
}

export interface UserSession {
  sessionId: string;
  userId?: string;
  startTime: Date;
  endTime?: Date;
  events: TrackedEvent[];
  totalDuration: number;
}

export class EventTrackingSystem {
  private events: Map<string, TrackedEvent> = new Map();
  private sessions: Map<string, UserSession> = new Map();
  private currentSessionId: string = "";
  private eventQueue: TrackedEvent[] = [];
  private maxQueueSize: number = 1000;

  constructor() {
    this.startNewSession();
  }

  /**
   * بدء جلسة جديدة
   */
  startNewSession(userId?: string): string {
    this.currentSessionId = this.generateSessionId();
    const session: UserSession = {
      sessionId: this.currentSessionId,
      userId,
      startTime: new Date(),
      events: [],
      totalDuration: 0,
    };
    this.sessions.set(this.currentSessionId, session);
    return this.currentSessionId;
  }

  /**
   * إنهاء الجلسة الحالية
   */
  endCurrentSession(): void {
    const session = this.sessions.get(this.currentSessionId);
    if (session) {
      session.endTime = new Date();
      session.totalDuration =
        session.endTime.getTime() - session.startTime.getTime();
    }
  }

  /**
   * تتبع حدث جديد
   */
  trackEvent(
    eventName: string,
    eventType: TrackedEvent["eventType"],
    data: Record<string, any> = {},
    duration?: number
  ): string {
    const eventId = this.generateEventId();
    const event: TrackedEvent = {
      id: eventId,
      eventName,
      eventType,
      timestamp: new Date(),
      sessionId: this.currentSessionId,
      data,
      duration,
      success: true,
    };

    this.events.set(eventId, event);
    this.eventQueue.push(event);

    // إضافة الحدث إلى الجلسة الحالية
    const session = this.sessions.get(this.currentSessionId);
    if (session) {
      session.events.push(event);
    }

    // إدارة حجم قائمة الانتظار
    if (this.eventQueue.length > this.maxQueueSize) {
      this.eventQueue.shift();
    }

    return eventId;
  }

  /**
   * تتبع حدث خطأ
   */
  trackError(
    eventName: string,
    error: Error,
    data: Record<string, any> = {}
  ): string {
    return this.trackEvent(eventName, "error", {
      ...data,
      errorMessage: error.message,
      errorStack: error.stack,
    });
  }

  /**
   * تتبع ضغطة مفتاح
   */
  trackKeyPress(noteKey: string, octave: number, frequency: number): string {
    return this.trackEvent("key_pressed", "key_press", {
      noteKey,
      octave,
      frequency,
      timestamp: new Date().getTime(),
    });
  }

  /**
   * تتبع بدء التسجيل
   */
  trackRecordingStart(recordingName: string): string {
    return this.trackEvent("recording_started", "recording", {
      recordingName,
      startTime: new Date().getTime(),
    });
  }

  /**
   * تتبع إنهاء التسجيل
   */
  trackRecordingEnd(recordingId: string, duration: number): string {
    return this.trackEvent("recording_ended", "recording", {
      recordingId,
      duration,
      endTime: new Date().getTime(),
    }, duration);
  }

  /**
   * تتبع تشغيل التسجيل
   */
  trackPlayback(recordingId: string, duration: number): string {
    return this.trackEvent("playback_started", "playback", {
      recordingId,
      duration,
    });
  }

  /**
   * تتبع تغيير الإعدادات
   */
  trackSettingChange(settingName: string, oldValue: any, newValue: any): string {
    return this.trackEvent("setting_changed", "settings", {
      settingName,
      oldValue,
      newValue,
    });
  }

  /**
   * تتبع التنقل بين الشاشات
   */
  trackNavigation(fromScreen: string, toScreen: string): string {
    return this.trackEvent("screen_navigated", "navigation", {
      fromScreen,
      toScreen,
    });
  }

  /**
   * الحصول على إحصائيات الأحداث
   */
  getEventStatistics(): EventStatistics {
    const events = Array.from(this.events.values());
    const eventsByType: Record<string, number> = {};
    const eventsByName: Record<string, number> = {};
    let totalDuration = 0;
    let successCount = 0;
    let errorCount = 0;

    events.forEach((event) => {
      eventsByType[event.eventType] = (eventsByType[event.eventType] || 0) + 1;
      eventsByName[event.eventName] = (eventsByName[event.eventName] || 0) + 1;

      if (event.duration) {
        totalDuration += event.duration;
      }

      if (event.success) {
        successCount += 1;
      } else {
        errorCount += 1;
      }
    });

    const totalEvents = events.length;
    const averageEventDuration = totalEvents > 0 ? totalDuration / totalEvents : 0;
    const successRate = totalEvents > 0 ? (successCount / totalEvents) * 100 : 0;
    const errorRate = totalEvents > 0 ? (errorCount / totalEvents) * 100 : 0;

    return {
      totalEvents,
      eventsByType,
      eventsByName,
      averageEventDuration,
      successRate,
      errorRate,
    };
  }

  /**
   * الحصول على إحصائيات الجلسة الحالية
   */
  getCurrentSessionStatistics(): EventStatistics {
    const session = this.sessions.get(this.currentSessionId);
    if (!session) {
      return {
        totalEvents: 0,
        eventsByType: {},
        eventsByName: {},
        averageEventDuration: 0,
        successRate: 0,
        errorRate: 0,
      };
    }

    const events = session.events;
    const eventsByType: Record<string, number> = {};
    const eventsByName: Record<string, number> = {};
    let totalDuration = 0;
    let successCount = 0;
    let errorCount = 0;

    events.forEach((event) => {
      eventsByType[event.eventType] = (eventsByType[event.eventType] || 0) + 1;
      eventsByName[event.eventName] = (eventsByName[event.eventName] || 0) + 1;

      if (event.duration) {
        totalDuration += event.duration;
      }

      if (event.success) {
        successCount += 1;
      } else {
        errorCount += 1;
      }
    });

    const totalEvents = events.length;
    const averageEventDuration = totalEvents > 0 ? totalDuration / totalEvents : 0;
    const successRate = totalEvents > 0 ? (successCount / totalEvents) * 100 : 0;
    const errorRate = totalEvents > 0 ? (errorCount / totalEvents) * 100 : 0;

    return {
      totalEvents,
      eventsByType,
      eventsByName,
      averageEventDuration,
      successRate,
      errorRate,
    };
  }

  /**
   * الحصول على الأحداث الأخيرة
   */
  getRecentEvents(limit: number = 50): TrackedEvent[] {
    return this.eventQueue.slice(-limit);
  }

  /**
   * الحصول على الأحداث حسب النوع
   */
  getEventsByType(eventType: TrackedEvent["eventType"]): TrackedEvent[] {
    return Array.from(this.events.values()).filter(
      (event) => event.eventType === eventType
    );
  }

  /**
   * الحصول على الأحداث حسب الاسم
   */
  getEventsByName(eventName: string): TrackedEvent[] {
    return Array.from(this.events.values()).filter(
      (event) => event.eventName === eventName
    );
  }

  /**
   * الحصول على جلسة محددة
   */
  getSession(sessionId: string): UserSession | undefined {
    return this.sessions.get(sessionId);
  }

  /**
   * الحصول على جميع الجلسات
   */
  getAllSessions(): UserSession[] {
    return Array.from(this.sessions.values());
  }

  /**
   * تصدير الأحداث كـ JSON
   */
  exportEvents(): string {
    return JSON.stringify(
      {
        events: Array.from(this.events.values()),
        sessions: Array.from(this.sessions.values()),
        statistics: this.getEventStatistics(),
      },
      null,
      2
    );
  }

  /**
   * تصدير الأحداث كـ CSV
   */
  exportEventsAsCSV(): string {
    const events = Array.from(this.events.values());
    const headers = [
      "Event ID",
      "Event Name",
      "Event Type",
      "Timestamp",
      "Session ID",
      "Duration (ms)",
      "Success",
    ];

    const rows = events.map((event) => [
      event.id,
      event.eventName,
      event.eventType,
      event.timestamp.toISOString(),
      event.sessionId,
      event.duration || "N/A",
      event.success ? "Yes" : "No",
    ]);

    const csv = [
      headers.join(","),
      ...rows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
    ].join("\n");

    return csv;
  }

  /**
   * مسح جميع البيانات
   */
  clear(): void {
    this.events.clear();
    this.sessions.clear();
    this.eventQueue = [];
  }

  /**
   * توليد معرف فريد للحدث
   */
  private generateEventId(): string {
    return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * توليد معرف فريد للجلسة
   */
  private generateSessionId(): string {
    return `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * مثيل عام من نظام تتبع الأحداث
 */
export const eventTrackingSystem = new EventTrackingSystem();
