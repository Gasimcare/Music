/**
 * خدمة توليد الأصوات الموسيقية
 * تستخدم Web Audio API لتوليد نبرات موسيقية
 */

import { NOTE_FREQUENCIES, InstrumentType } from "./musical-constants";

interface AudioContextType {
  audioContext: AudioContext | null;
  oscillators: Map<string, OscillatorNode>;
  gainNodes: Map<string, GainNode>;
  masterGain: GainNode | null;
}

let audioState: AudioContextType = {
  audioContext: null,
  oscillators: new Map(),
  gainNodes: new Map(),
  masterGain: null,
};

/**
 * تهيئة سياق الصوت
 */
export function initializeAudioContext(): AudioContext {
  if (audioState.audioContext) {
    return audioState.audioContext;
  }

  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  audioState.audioContext = audioContext;

  // إنشاء عقدة الكسب الرئيسية
  const masterGain = audioContext.createGain();
  masterGain.gain.value = 0.3; // تقليل الصوت الافتراضي
  masterGain.connect(audioContext.destination);
  audioState.masterGain = masterGain;

  return audioContext;
}

/**
 * تشغيل نغمة موسيقية
 */
export function playNote(
  note: string,
  duration: number = 2000,
  instrument: InstrumentType = InstrumentType.PIANO,
  volume: number = 0.7
): void {
  const audioContext = initializeAudioContext();
  const frequency = NOTE_FREQUENCIES[note];

  if (!frequency || !audioState.masterGain) {
    console.warn(`Note ${note} not found or audio context not initialized`);
    return;
  }

  // إنشاء oscillator
  const oscillator = audioContext.createOscillator();
  oscillator.frequency.value = frequency;

  // تعيين نوع الموجة حسب الآلة الموسيقية
  switch (instrument) {
    case InstrumentType.PIANO:
      oscillator.type = "sine";
      break;
    case InstrumentType.ORGAN:
      oscillator.type = "square";
      break;
    case InstrumentType.DIGITAL_PIANO:
      oscillator.type = "triangle";
      break;
    default:
      oscillator.type = "sine";
  }

  // إنشاء عقدة الكسب للنغمة الفردية
  const gainNode = audioContext.createGain();
  gainNode.gain.value = volume;

  // إنشاء envelope للصوت (ADSR)
  const now = audioContext.currentTime;
  const attackTime = 0.05; // 50ms
  const decayTime = 0.1; // 100ms
  const sustainLevel = 0.6;
  const releaseTime = 0.3; // 300ms

  // Attack
  gainNode.gain.setValueAtTime(0, now);
  gainNode.gain.linearRampToValueAtTime(volume, now + attackTime);

  // Decay
  gainNode.gain.linearRampToValueAtTime(
    volume * sustainLevel,
    now + attackTime + decayTime
  );

  // Sustain (يبقى على هذا المستوى)
  gainNode.gain.setValueAtTime(volume * sustainLevel, now + attackTime + decayTime);

  // Release
  const endTime = now + duration / 1000;
  gainNode.gain.linearRampToValueAtTime(0, endTime + releaseTime);

  // ربط العقد
  oscillator.connect(gainNode);
  gainNode.connect(audioState.masterGain);

  // تشغيل الصوت
  oscillator.start(now);
  oscillator.stop(endTime + releaseTime);

  // تخزين المؤشرات
  audioState.oscillators.set(note, oscillator);
  audioState.gainNodes.set(note, gainNode);

  // تنظيف بعد انتهاء الصوت
  setTimeout(() => {
    audioState.oscillators.delete(note);
    audioState.gainNodes.delete(note);
  }, (duration + releaseTime * 1000) + 100);
}

/**
 * إيقاف نغمة موسيقية
 */
export function stopNote(note: string): void {
  const gainNode = audioState.gainNodes.get(note);
  if (gainNode && audioState.audioContext) {
    const now = audioState.audioContext.currentTime;
    gainNode.gain.linearRampToValueAtTime(0, now + 0.1);
  }
}

/**
 * تعيين مستوى الصوت الرئيسي
 */
export function setMasterVolume(volume: number): void {
  if (audioState.masterGain) {
    audioState.masterGain.gain.value = Math.max(0, Math.min(1, volume));
  }
}

/**
 * الحصول على مستوى الصوت الرئيسي
 */
export function getMasterVolume(): number {
  return audioState.masterGain?.gain.value ?? 0.3;
}

/**
 * إيقاف جميع الأصوات
 */
export function stopAllNotes(): void {
  audioState.oscillators.forEach((oscillator) => {
    try {
      oscillator.stop();
    } catch (e) {
      // قد يكون الصوت قد توقف بالفعل
    }
  });
  audioState.oscillators.clear();
  audioState.gainNodes.clear();
}

/**
 * تنظيف سياق الصوت
 */
export function cleanupAudioContext(): void {
  stopAllNotes();
  if (audioState.audioContext) {
    audioState.audioContext.close();
  }
  audioState = {
    audioContext: null,
    oscillators: new Map(),
    gainNodes: new Map(),
    masterGain: null,
  };
}
