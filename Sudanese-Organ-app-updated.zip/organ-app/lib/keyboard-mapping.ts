export type KeyboardNote =
  | "C"
  | "C#"
  | "D"
  | "D#"
  | "E"
  | "F"
  | "F#"
  | "G"
  | "G#"
  | "A"
  | "A#"
  | "B";

/** Standard QWERTY chromatic layout for playing one octave. */
export const KEYBOARD_NOTE_MAP: Readonly<Record<string, KeyboardNote>> = {
  a: "C",
  w: "C#",
  s: "D",
  e: "D#",
  d: "E",
  f: "F",
  t: "F#",
  g: "G",
  y: "G#",
  h: "A",
  u: "A#",
  j: "B",
};

export const KEYBOARD_INSTRUCTIONS = "A W S E D F T G Y H U J";

export function getMappedNote(key: string): KeyboardNote | undefined {
  return KEYBOARD_NOTE_MAP[key.toLowerCase()];
}

export function getOctaveFromKey(key: string): number | null {
  if (/^[0-9]$/.test(key)) return Number(key);
  return null;
}
