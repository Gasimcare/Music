/**
 * نظام مشاركة الألحان
 */

export interface SharedMelody {
  id: string;
  melodyId: string;
  melodyName: string;
  shareCode: string;
  creatorName: string;
  createdAt: Date;
  expiresAt?: Date;
  views: number;
  downloads: number;
  isPublic: boolean;
}

export interface ShareLink {
  url: string;
  code: string;
  expiresAt?: Date;
}

export class SharingSystem {
  private sharedMelodies: Map<string, SharedMelody> = new Map();
  private shareLinks: Map<string, ShareLink> = new Map();
  private baseUrl = "https://sudanese-organ.app/share";

  /**
   * إنشاء رابط مشاركة
   */
  createShareLink(
    melodyId: string,
    melodyName: string,
    creatorName: string,
    expirationDays?: number
  ): ShareLink {
    const shareCode = this.generateShareCode();
    const expiresAt = expirationDays
      ? new Date(Date.now() + expirationDays * 24 * 60 * 60 * 1000)
      : undefined;

    const shareLink: ShareLink = {
      url: `${this.baseUrl}/${shareCode}`,
      code: shareCode,
      expiresAt,
    };

    const sharedMelody: SharedMelody = {
      id: `shared-${Date.now()}`,
      melodyId,
      melodyName,
      shareCode,
      creatorName,
      createdAt: new Date(),
      expiresAt,
      views: 0,
      downloads: 0,
      isPublic: true,
    };

    this.sharedMelodies.set(shareCode, sharedMelody);
    this.shareLinks.set(shareCode, shareLink);

    return shareLink;
  }

  /**
   * الحصول على اللحن المشارك
   */
  getSharedMelody(shareCode: string): SharedMelody | null {
    const melody = this.sharedMelodies.get(shareCode);

    if (!melody) return null;

    // التحقق من انتهاء الصلاحية
    if (melody.expiresAt && melody.expiresAt < new Date()) {
      this.sharedMelodies.delete(shareCode);
      return null;
    }

    // زيادة عدد المشاهدات
    melody.views += 1;

    return melody;
  }

  /**
   * تحميل اللحن المشارك
   */
  downloadSharedMelody(shareCode: string): SharedMelody | null {
    const melody = this.getSharedMelody(shareCode);

    if (!melody) return null;

    melody.downloads += 1;
    return melody;
  }

  /**
   * حذف رابط المشاركة
   */
  deleteShareLink(shareCode: string): boolean {
    this.sharedMelodies.delete(shareCode);
    return this.shareLinks.delete(shareCode);
  }

  /**
   * الحصول على جميع الروابط المشاركة
   */
  getAllSharedMelodies(): SharedMelody[] {
    return Array.from(this.sharedMelodies.values()).filter((melody) => {
      // إزالة الروابط المنتهية الصلاحية
      if (melody.expiresAt && melody.expiresAt < new Date()) {
        this.sharedMelodies.delete(melody.shareCode);
        return false;
      }
      return true;
    });
  }

  /**
   * الحصول على الألحان الشهيرة
   */
  getPopularMelodies(limit: number = 10): SharedMelody[] {
    return this.getAllSharedMelodies()
      .sort((a, b) => b.views - a.views)
      .slice(0, limit);
  }

  /**
   * الحصول على الألحان الأكثر تحميلاً
   */
  getMostDownloadedMelodies(limit: number = 10): SharedMelody[] {
    return this.getAllSharedMelodies()
      .sort((a, b) => b.downloads - a.downloads)
      .slice(0, limit);
  }

  /**
   * البحث عن الألحان المشاركة
   */
  searchSharedMelodies(query: string): SharedMelody[] {
    const lowerQuery = query.toLowerCase();
    return this.getAllSharedMelodies().filter(
      (melody) =>
        melody.melodyName.toLowerCase().includes(lowerQuery) ||
        melody.creatorName.toLowerCase().includes(lowerQuery)
    );
  }

  /**
   * مشاركة عبر وسائل التواصل
   */
  generateSocialShareText(melody: SharedMelody): {
    twitter: string;
    facebook: string;
    whatsapp: string;
  } {
    const baseText = `تحقق من اللحن "${melody.melodyName}" الذي أنشأه ${melody.creatorName} على Sudanese Organ!`;
    const url = `${this.baseUrl}/${melody.shareCode}`;

    return {
      twitter: `${baseText} ${url}`,
      facebook: `${baseText}\n${url}`,
      whatsapp: `${baseText}\n${url}`,
    };
  }

  /**
   * إنشاء كود مشاركة عشوائي
   */
  private generateShareCode(): string {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let code = "";
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  /**
   * التحقق من صحة كود المشاركة
   */
  isValidShareCode(code: string): boolean {
    const melody = this.sharedMelodies.get(code);
    if (!melody) return false;

    // التحقق من انتهاء الصلاحية
    if (melody.expiresAt && melody.expiresAt < new Date()) {
      this.sharedMelodies.delete(code);
      return false;
    }

    return true;
  }

  /**
   * تحديث معلومات المشاركة
   */
  updateShareInfo(
    shareCode: string,
    updates: Partial<SharedMelody>
  ): SharedMelody | null {
    const melody = this.sharedMelodies.get(shareCode);
    if (!melody) return null;

    Object.assign(melody, updates);
    return melody;
  }

  /**
   * الحصول على إحصائيات المشاركة
   */
  getShareStats(shareCode: string): {
    views: number;
    downloads: number;
    shareRatio: number;
    createdDaysAgo: number;
  } | null {
    const melody = this.getSharedMelody(shareCode);
    if (!melody) return null;

    const createdDaysAgo = Math.floor(
      (Date.now() - melody.createdAt.getTime()) / (1000 * 60 * 60 * 24)
    );

    return {
      views: melody.views,
      downloads: melody.downloads,
      shareRatio: melody.downloads > 0 ? melody.views / melody.downloads : 0,
      createdDaysAgo,
    };
  }
}
