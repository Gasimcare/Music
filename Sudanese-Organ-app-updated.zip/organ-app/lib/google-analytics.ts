/**
 * نظام Google Analytics للتطبيق
 * يتكامل مع Google Analytics لتتبع الأحداث والإحصائيات
 */

export interface AnalyticsConfig {
  measurementId: string;
  apiSecret: string;
  enabled: boolean;
}

export interface AnalyticsEvent {
  name: string;
  params: Record<string, any>;
}

export class GoogleAnalytics {
  private config: AnalyticsConfig;
  private sessionId: string = "";
  private userId: string = "";
  private clientId: string = "";
  private eventQueue: AnalyticsEvent[] = [];
  private isInitialized: boolean = false;

  constructor(config: AnalyticsConfig) {
    this.config = config;
    this.generateClientId();
    this.initialize();
  }

  /**
   * تهيئة Google Analytics
   */
  private initialize(): void {
    if (!this.config.enabled) {
      console.log("Google Analytics is disabled");
      return;
    }

    this.sessionId = this.generateSessionId();
    this.isInitialized = true;
    console.log("Google Analytics initialized");
  }

  /**
   * تعيين معرف المستخدم
   */
  setUserId(userId: string): void {
    this.userId = userId;
  }

  /**
   * تتبع حدث
   */
  logEvent(eventName: string, params: Record<string, any> = {}): void {
    if (!this.isInitialized || !this.config.enabled) {
      return;
    }

    const event: AnalyticsEvent = {
      name: eventName,
      params: {
        ...params,
        timestamp: new Date().toISOString(),
        session_id: this.sessionId,
      },
    };

    this.eventQueue.push(event);
    this.sendEvent(event);
  }

  /**
   * تتبع ضغطة مفتاح
   */
  logKeyPress(noteKey: string, octave: number, frequency: number): void {
    this.logEvent("key_pressed", {
      note_key: noteKey,
      octave,
      frequency,
    });
  }

  /**
   * تتبع بدء التسجيل
   */
  logRecordingStart(recordingName: string): void {
    this.logEvent("recording_started", {
      recording_name: recordingName,
    });
  }

  /**
   * تتبع إنهاء التسجيل
   */
  logRecordingEnd(recordingId: string, duration: number): void {
    this.logEvent("recording_ended", {
      recording_id: recordingId,
      duration_ms: duration,
    });
  }

  /**
   * تتبع تشغيل التسجيل
   */
  logPlayback(recordingId: string, duration: number): void {
    this.logEvent("playback_started", {
      recording_id: recordingId,
      duration_ms: duration,
    });
  }

  /**
   * تتبع تغيير الإعدادات
   */
  logSettingChange(settingName: string, oldValue: any, newValue: any): void {
    this.logEvent("setting_changed", {
      setting_name: settingName,
      old_value: String(oldValue),
      new_value: String(newValue),
    });
  }

  /**
   * تتبع التنقل بين الشاشات
   */
  logScreenView(screenName: string): void {
    this.logEvent("screen_view", {
      screen_name: screenName,
    });
  }

  /**
   * تتبع الأخطاء
   */
  logError(errorName: string, errorMessage: string): void {
    this.logEvent("error", {
      error_name: errorName,
      error_message: errorMessage,
    });
  }

  /**
   * إرسال الحدث إلى Google Analytics
   */
  private sendEvent(event: AnalyticsEvent): void {
    if (!this.config.enabled) {
      return;
    }

    // محاكاة إرسال الحدث إلى Google Analytics
    // في التطبيق الحقيقي، سيتم إرسال الطلب إلى خادم Google Analytics
    console.log("Sending event to Google Analytics:", event);

    // يمكن إضافة الكود الفعلي هنا لإرسال البيانات إلى Google Analytics
    // fetch(`https://www.google-analytics.com/mp/collect?measurement_id=${this.config.measurementId}&api_secret=${this.config.apiSecret}`, {
    //   method: 'POST',
    //   body: JSON.stringify({
    //     client_id: this.clientId,
    //     user_id: this.userId,
    //     events: [event],
    //   }),
    // });
  }

  /**
   * إرسال جميع الأحداث المعلقة
   */
  flushEvents(): void {
    if (this.eventQueue.length === 0) {
      return;
    }

    console.log(`Flushing ${this.eventQueue.length} events to Google Analytics`);
    this.eventQueue = [];
  }

  /**
   * توليد معرف العميل الفريد
   */
  private generateClientId(): string {
    this.clientId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    return this.clientId;
  }

  /**
   * توليد معرف الجلسة الفريد
   */
  private generateSessionId(): string {
    return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * الحصول على معرف العميل
   */
  getClientId(): string {
    return this.clientId;
  }

  /**
   * الحصول على معرف الجلسة
   */
  getSessionId(): string {
    return this.sessionId;
  }

  /**
   * الحصول على معرف المستخدم
   */
  getUserId(): string {
    return this.userId;
  }
}

/**
 * مثيل عام من Google Analytics
 */
export const googleAnalytics = new GoogleAnalytics({
  measurementId: process.env.EXPO_PUBLIC_GA_MEASUREMENT_ID || "",
  apiSecret: process.env.EXPO_PUBLIC_GA_API_SECRET || "",
  enabled: true,
});
