/**
 * نظام التسجيل والتشغيل للألحان
 */

export interface RecordedNote {
  note: string;
  frequency: number;
  timestamp: number;
  duration: number;
  volume: number;
}

export interface RecordedMelody {
  id: string;
  name: string;
  notes: RecordedNote[];
  duration: number;
  createdAt: Date;
  updatedAt: Date;
}

export class RecordingSystem {
  private isRecording = false;
  private recordedNotes: RecordedNote[] = [];
  private recordingStartTime = 0;
  private melodies: Map<string, RecordedMelody> = new Map();

  /**
   * بدء التسجيل
   */
  startRecording(): void {
    this.isRecording = true;
    this.recordedNotes = [];
    this.recordingStartTime = Date.now();
  }

  /**
   * إيقاف التسجيل
   */
  stopRecording(): RecordedMelody | null {
    if (!this.isRecording) return null;

    this.isRecording = false;
    const duration = Date.now() - this.recordingStartTime;
    const melody: RecordedMelody = {
      id: `melody-${Date.now()}`,
      name: `Melody ${new Date().toLocaleString()}`,
      notes: this.recordedNotes,
      duration,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.melodies.set(melody.id, melody);
    return melody;
  }

  /**
   * تسجيل نغمة
   */
  recordNote(
    note: string,
    frequency: number,
    volume: number,
    duration: number
  ): void {
    if (!this.isRecording) return;

    const recordedNote: RecordedNote = {
      note,
      frequency,
      timestamp: Date.now() - this.recordingStartTime,
      duration,
      volume,
    };

    this.recordedNotes.push(recordedNote);
  }

  /**
   * الحصول على حالة التسجيل
   */
  getRecordingStatus(): {
    isRecording: boolean;
    duration: number;
    notesCount: number;
  } {
    return {
      isRecording: this.isRecording,
      duration: this.isRecording ? Date.now() - this.recordingStartTime : 0,
      notesCount: this.recordedNotes.length,
    };
  }

  /**
   * حفظ اللحن
   */
  saveMelody(melody: RecordedMelody, name: string): RecordedMelody {
    const savedMelody: RecordedMelody = {
      ...melody,
      name,
      updatedAt: new Date(),
    };

    this.melodies.set(melody.id, savedMelody);
    return savedMelody;
  }

  /**
   * الحصول على قائمة الألحان المحفوظة
   */
  getSavedMelodies(): RecordedMelody[] {
    return Array.from(this.melodies.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  /**
   * حذف لحن
   */
  deleteMelody(id: string): boolean {
    return this.melodies.delete(id);
  }

  /**
   * الحصول على لحن محدد
   */
  getMelody(id: string): RecordedMelody | undefined {
    return this.melodies.get(id);
  }

  /**
   * تصدير اللحن كـ JSON
   */
  exportMelodyAsJSON(id: string): string | null {
    const melody = this.melodies.get(id);
    if (!melody) return null;

    return JSON.stringify(melody, null, 2);
  }

  /**
   * استيراد لحن من JSON
   */
  importMelodyFromJSON(jsonString: string): RecordedMelody | null {
    try {
      const melody = JSON.parse(jsonString) as RecordedMelody;
      if (!melody.id || !melody.notes) return null;

      this.melodies.set(melody.id, melody);
      return melody;
    } catch (error) {
      console.error("Failed to import melody:", error);
      return null;
    }
  }

  /**
   * تشغيل اللحن
   */
  async playMelody(
    id: string,
    onNotePlay: (note: RecordedNote) => Promise<void>
  ): Promise<void> {
    const melody = this.melodies.get(id);
    if (!melody) return;

    for (const note of melody.notes) {
      await onNotePlay(note);
      // انتظر حتى انتهاء النغمة
      await new Promise((resolve) =>
        setTimeout(resolve, note.duration + 50)
      );
    }
  }

  /**
   * حساب إحصائيات اللحن
   */
  getMelodyStats(id: string): {
    totalNotes: number;
    duration: number;
    averageVolume: number;
    highestFrequency: number;
    lowestFrequency: number;
  } | null {
    const melody = this.melodies.get(id);
    if (!melody || melody.notes.length === 0) return null;

    const totalVolume = melody.notes.reduce((sum, note) => sum + note.volume, 0);
    const frequencies = melody.notes.map((note) => note.frequency);

    return {
      totalNotes: melody.notes.length,
      duration: melody.duration,
      averageVolume: totalVolume / melody.notes.length,
      highestFrequency: Math.max(...frequencies),
      lowestFrequency: Math.min(...frequencies),
    };
  }

  /**
   * مسح جميع الألحان
   */
  clearAllMelodies(): void {
    this.melodies.clear();
  }
}
