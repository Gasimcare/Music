/**
 * نظام Firebase للتطبيق
 * يتكامل مع Firebase للإشعارات والتحليلات
 */

export interface FirebaseConfig {
  apiKey: string;
  projectId: string;
  messagingSenderId: string;
  enabled: boolean;
}

export interface PushNotification {
  id: string;
  title: string;
  body: string;
  data: Record<string, any>;
  timestamp: Date;
  read: boolean;
}

export interface FirebaseAnalyticsEvent {
  name: string;
  params: Record<string, any>;
  timestamp: Date;
}

export class FirebaseSystem {
  private config: FirebaseConfig;
  private isInitialized: boolean = false;
  private notifications: Map<string, PushNotification> = new Map();
  private analyticsEvents: FirebaseAnalyticsEvent[] = [];
  private deviceToken: string = "";

  constructor(config: FirebaseConfig) {
    this.config = config;
    this.initialize();
  }

  /**
   * تهيئة Firebase
   */
  private initialize(): void {
    if (!this.config.enabled) {
      console.log("Firebase is disabled");
      return;
    }

    this.deviceToken = this.generateDeviceToken();
    this.isInitialized = true;
    console.log("Firebase initialized with device token:", this.deviceToken);
  }

  /**
   * تسجيل حدث تحليلي
   */
  logAnalyticsEvent(eventName: string, params: Record<string, any> = {}): void {
    if (!this.isInitialized || !this.config.enabled) {
      return;
    }

    const event: FirebaseAnalyticsEvent = {
      name: eventName,
      params,
      timestamp: new Date(),
    };

    this.analyticsEvents.push(event);
    console.log("Firebase Analytics Event:", event);
  }

  /**
   * إرسال إشعار فوري
   */
  sendNotification(title: string, body: string, data: Record<string, any> = {}): string {
    if (!this.isInitialized || !this.config.enabled) {
      return "";
    }

    const notificationId = this.generateNotificationId();
    const notification: PushNotification = {
      id: notificationId,
      title,
      body,
      data,
      timestamp: new Date(),
      read: false,
    };

    this.notifications.set(notificationId, notification);
    console.log("Notification sent:", notification);

    return notificationId;
  }

  /**
   * إرسال إشعار جدول زمني
   */
  scheduleNotification(
    title: string,
    body: string,
    delayMs: number,
    data: Record<string, any> = {}
  ): string {
    if (!this.isInitialized || !this.config.enabled) {
      return "";
    }

    const notificationId = this.generateNotificationId();

    setTimeout(() => {
      const notification: PushNotification = {
        id: notificationId,
        title,
        body,
        data,
        timestamp: new Date(),
        read: false,
      };

      this.notifications.set(notificationId, notification);
      console.log("Scheduled notification sent:", notification);
    }, delayMs);

    return notificationId;
  }

  /**
   * تحديد الإشعار كمقروء
   */
  markNotificationAsRead(notificationId: string): void {
    const notification = this.notifications.get(notificationId);
    if (notification) {
      notification.read = true;
    }
  }

  /**
   * الحصول على جميع الإشعارات
   */
  getAllNotifications(): PushNotification[] {
    return Array.from(this.notifications.values());
  }

  /**
   * الحصول على الإشعارات غير المقروءة
   */
  getUnreadNotifications(): PushNotification[] {
    return Array.from(this.notifications.values()).filter((n) => !n.read);
  }

  /**
   * حذف إشعار
   */
  deleteNotification(notificationId: string): void {
    this.notifications.delete(notificationId);
  }

  /**
   * حذف جميع الإشعارات
   */
  clearAllNotifications(): void {
    this.notifications.clear();
  }

  /**
   * الحصول على عدد الإشعارات غير المقروءة
   */
  getUnreadNotificationCount(): number {
    return this.getUnreadNotifications().length;
  }

  /**
   * إرسال إشعار عند إكمال التسجيل
   */
  notifyRecordingCompleted(recordingName: string, duration: number): string {
    return this.sendNotification(
      "تم إكمال التسجيل",
      `تم حفظ التسجيل "${recordingName}" بنجاح (${Math.round(duration / 1000)} ثانية)`,
      {
        type: "recording_completed",
        recordingName,
        duration,
      }
    );
  }

  /**
   * إرسال إشعار عند إكمال الدرس
   */
  notifyLessonCompleted(lessonName: string): string {
    return this.sendNotification(
      "تم إكمال الدرس",
      `مبروك! لقد أكملت الدرس "${lessonName}" بنجاح`,
      {
        type: "lesson_completed",
        lessonName,
      }
    );
  }

  /**
   * إرسال إشعار بالإنجازات
   */
  notifyAchievement(achievementName: string, description: string): string {
    return this.sendNotification(
      "إنجاز جديد! 🏆",
      `${achievementName}: ${description}`,
      {
        type: "achievement",
        achievementName,
      }
    );
  }

  /**
   * الحصول على معرف الجهاز
   */
  getDeviceToken(): string {
    return this.deviceToken;
  }

  /**
   * الحصول على جميع أحداث التحليلات
   */
  getAllAnalyticsEvents(): FirebaseAnalyticsEvent[] {
    return this.analyticsEvents;
  }

  /**
   * مسح أحداث التحليلات
   */
  clearAnalyticsEvents(): void {
    this.analyticsEvents = [];
  }

  /**
   * توليد معرف فريد للإشعار
   */
  private generateNotificationId(): string {
    return `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * توليد معرف فريد للجهاز
   */
  private generateDeviceToken(): string {
    return `device_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * مثيل عام من Firebase
 */
export const firebaseSystem = new FirebaseSystem({
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY || "",
  projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID || "",
  messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "",
  enabled: true,
});
