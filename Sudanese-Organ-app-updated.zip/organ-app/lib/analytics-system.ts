/**
 * نظام تحليل الأداء والإحصائيات
 */

export interface UserSession {
  sessionId: string;
  startTime: Date;
  endTime?: Date;
  totalNotesPlayed: number;
  totalRecordingTime: number;
  lessonsCompleted: number;
  averageSessionDuration: number;
}

export interface NoteStatistics {
  noteName: string;
  frequency: number;
  timesPlayed: number;
  totalDuration: number;
  averageDuration: number;
}

export interface AppStatistics {
  totalSessions: number;
  totalNotesPlayed: number;
  totalRecordingTime: number;
  mostPlayedNote: string;
  averageSessionDuration: number;
  userLevel: "beginner" | "intermediate" | "advanced";
}

export class AnalyticsSystem {
  private currentSession: UserSession | null = null;
  private sessions: UserSession[] = [];
  private noteStats: Map<string, NoteStatistics> = new Map();
  private sessionStartTime: number = 0;

  /**
   * بدء جلسة جديدة
   */
  startSession(): string {
    const sessionId = `session-${Date.now()}`;
    this.currentSession = {
      sessionId,
      startTime: new Date(),
      totalNotesPlayed: 0,
      totalRecordingTime: 0,
      lessonsCompleted: 0,
      averageSessionDuration: 0,
    };
    this.sessionStartTime = Date.now();
    return sessionId;
  }

  /**
   * إنهاء الجلسة الحالية
   */
  endSession(): UserSession | null {
    if (!this.currentSession) return null;

    this.currentSession.endTime = new Date();
    this.currentSession.averageSessionDuration =
      (Date.now() - this.sessionStartTime) / 1000; // بالثواني

    this.sessions.push(this.currentSession);
    const endedSession = this.currentSession;
    this.currentSession = null;

    return endedSession;
  }

  /**
   * تسجيل نغمة تم عزفها
   */
  recordNotePlay(noteName: string, frequency: number, duration: number): void {
    if (!this.currentSession) return;

    this.currentSession.totalNotesPlayed += 1;

    let noteStats = this.noteStats.get(noteName);
    if (!noteStats) {
      noteStats = {
        noteName,
        frequency,
        timesPlayed: 0,
        totalDuration: 0,
        averageDuration: 0,
      };
      this.noteStats.set(noteName, noteStats);
    }

    noteStats.timesPlayed += 1;
    noteStats.totalDuration += duration;
    noteStats.averageDuration = noteStats.totalDuration / noteStats.timesPlayed;
  }

  /**
   * تسجيل وقت التسجيل
   */
  recordRecordingTime(duration: number): void {
    if (!this.currentSession) return;
    this.currentSession.totalRecordingTime += duration;
  }

  /**
   * تسجيل درس مكتمل
   */
  recordLessonCompleted(): void {
    if (!this.currentSession) return;
    this.currentSession.lessonsCompleted += 1;
  }

  /**
   * الحصول على إحصائيات التطبيق
   */
  getAppStatistics(): AppStatistics {
    let totalNotesPlayed = 0;
    let totalRecordingTime = 0;
    let totalSessions = this.sessions.length;
    let averageSessionDuration = 0;
    let mostPlayedNote = "";
    let maxPlays = 0;

    // حساب الإحصائيات من الجلسات
    this.sessions.forEach((session) => {
      totalNotesPlayed += session.totalNotesPlayed;
      totalRecordingTime += session.totalRecordingTime;
      averageSessionDuration += session.averageSessionDuration;
    });

    if (totalSessions > 0) {
      averageSessionDuration /= totalSessions;
    }

    // البحث عن أكثر نغمة تم عزفها
    this.noteStats.forEach((stats) => {
      if (stats.timesPlayed > maxPlays) {
        maxPlays = stats.timesPlayed;
        mostPlayedNote = stats.noteName;
      }
    });

    // تحديد مستوى المستخدم
    let userLevel: "beginner" | "intermediate" | "advanced" = "beginner";
    if (totalNotesPlayed > 1000) {
      userLevel = "advanced";
    } else if (totalNotesPlayed > 500) {
      userLevel = "intermediate";
    }

    return {
      totalSessions,
      totalNotesPlayed,
      totalRecordingTime,
      mostPlayedNote,
      averageSessionDuration,
      userLevel,
    };
  }

  /**
   * الحصول على إحصائيات النغمات
   */
  getNoteStatistics(): NoteStatistics[] {
    return Array.from(this.noteStats.values()).sort(
      (a, b) => b.timesPlayed - a.timesPlayed
    );
  }

  /**
   * الحصول على أفضل النغمات
   */
  getTopNotes(limit: number = 10): NoteStatistics[] {
    return this.getNoteStatistics().slice(0, limit);
  }

  /**
   * الحصول على الجلسات السابقة
   */
  getPreviousSessions(): UserSession[] {
    return [...this.sessions];
  }

  /**
   * حساب تقدم المستخدم
   */
  getUserProgress(): {
    level: string;
    progress: number;
    nextMilestone: number;
  } {
    const stats = this.getAppStatistics();
    let progress = 0;
    let nextMilestone = 500;

    if (stats.totalNotesPlayed < 500) {
      progress = (stats.totalNotesPlayed / 500) * 100;
      nextMilestone = 500;
    } else if (stats.totalNotesPlayed < 1000) {
      progress = ((stats.totalNotesPlayed - 500) / 500) * 100;
      nextMilestone = 1000;
    } else {
      progress = 100;
      nextMilestone = stats.totalNotesPlayed + 500;
    }

    return {
      level: stats.userLevel,
      progress: Math.min(100, progress),
      nextMilestone,
    };
  }

  /**
   * تصدير الإحصائيات كـ JSON
   */
  exportStatistics(): string {
    return JSON.stringify(
      {
        appStatistics: this.getAppStatistics(),
        noteStatistics: this.getNoteStatistics(),
        userProgress: this.getUserProgress(),
        sessions: this.sessions,
      },
      null,
      2
    );
  }

  /**
   * مسح جميع الإحصائيات
   */
  clearStatistics(): void {
    this.sessions = [];
    this.noteStats.clear();
    this.currentSession = null;
  }
}

/**
 * مثيل عام من نظام التحليلات
 */
export const analyticsSystem = new AnalyticsSystem();
