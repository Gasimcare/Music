/**
 * نظام الدروس الموسيقية التفاعلية
 */

export interface Lesson {
  id: string;
  title: string;
  description: string;
  level: "beginner" | "intermediate" | "advanced";
  steps: LessonStep[];
  duration: number; // بالدقائق
  createdAt: Date;
}

export interface LessonStep {
  id: string;
  title: string;
  instructions: string;
  targetNotes: string[];
  hint: string;
  completed: boolean;
}

export class LessonsSystem {
  private lessons: Map<string, Lesson> = new Map();
  private userProgress: Map<string, LessonProgress> = new Map();

  constructor() {
    this.initializeDefaultLessons();
  }

  /**
   * تهيئة الدروس الافتراضية
   */
  private initializeDefaultLessons(): void {
    const beginnerLesson: Lesson = {
      id: "lesson-1",
      title: "مقدمة إلى لوحة المفاتيح",
      description: "تعلم أساسيات العزف على لوحة المفاتيح",
      level: "beginner",
      duration: 15,
      createdAt: new Date(),
      steps: [
        {
          id: "step-1",
          title: "تعريف المفاتيح",
          instructions: "تعرف على موقع المفاتيح البيضاء والسوداء",
          targetNotes: ["C", "D", "E", "F", "G", "A", "B"],
          hint: "ابدأ من المفتاح الأوسط C",
          completed: false,
        },
        {
          id: "step-2",
          title: "العزف بيد واحدة",
          instructions: "حاول العزف على النغمات بالترتيب من C إلى C",
          targetNotes: ["C", "D", "E", "F", "G", "A", "B", "C"],
          hint: "تحرك ببطء وركز على الدقة",
          completed: false,
        },
        {
          id: "step-3",
          title: "تعلم الإيقاع",
          instructions: "اعزف النغمات بإيقاع منتظم",
          targetNotes: ["C", "E", "G"],
          hint: "استخدم نمط ثابت للعزف",
          completed: false,
        },
      ],
    };

    const intermediateLesson: Lesson = {
      id: "lesson-2",
      title: "تعلم الألحان البسيطة",
      description: "اعزف ألحان كلاسيكية بسيطة",
      level: "intermediate",
      duration: 30,
      createdAt: new Date(),
      steps: [
        {
          id: "step-4",
          title: "لحن Twinkle Twinkle Little Star",
          instructions: "اعزف اللحن الشهير خطوة بخطوة",
          targetNotes: ["C", "C", "G", "A", "G"],
          hint: "ركز على الإيقاع الصحيح",
          completed: false,
        },
        {
          id: "step-5",
          title: "إضافة التأثيرات",
          instructions: "أضف تأثير Sustain إلى اللحن",
          targetNotes: ["C", "D", "E"],
          hint: "استخدم إعدادات الصوت لتحسين الجودة",
          completed: false,
        },
      ],
    };

    const advancedLesson: Lesson = {
      id: "lesson-3",
      title: "العزف المتقدم",
      description: "تعلم تقنيات عزف متقدمة",
      level: "advanced",
      duration: 60,
      createdAt: new Date(),
      steps: [
        {
          id: "step-6",
          title: "العزف بيدين",
          instructions: "تعلم تنسيق اليدين",
          targetNotes: ["C", "E", "G"],
          hint: "ابدأ ببطء وزد السرعة تدريجياً",
          completed: false,
        },
        {
          id: "step-7",
          title: "الارتجال الموسيقي",
          instructions: "ارتجل لحناً خاصاً بك",
          targetNotes: ["C", "D", "E", "F", "G", "A", "B"],
          hint: "استمع إلى ما تعزفه وعدّله",
          completed: false,
        },
      ],
    };

    this.lessons.set(beginnerLesson.id, beginnerLesson);
    this.lessons.set(intermediateLesson.id, intermediateLesson);
    this.lessons.set(advancedLesson.id, advancedLesson);
  }

  /**
   * الحصول على جميع الدروس
   */
  getAllLessons(): Lesson[] {
    return Array.from(this.lessons.values());
  }

  /**
   * الحصول على دروس حسب المستوى
   */
  getLessonsByLevel(level: "beginner" | "intermediate" | "advanced"): Lesson[] {
    return Array.from(this.lessons.values()).filter(
      (lesson) => lesson.level === level
    );
  }

  /**
   * الحصول على درس محدد
   */
  getLesson(id: string): Lesson | undefined {
    return this.lessons.get(id);
  }

  /**
   * بدء درس
   */
  startLesson(lessonId: string): LessonProgress | null {
    const lesson = this.lessons.get(lessonId);
    if (!lesson) return null;

    const progress: LessonProgress = {
      lessonId,
      startedAt: new Date(),
      completedSteps: 0,
      currentStepIndex: 0,
      isCompleted: false,
    };

    this.userProgress.set(lessonId, progress);
    return progress;
  }

  /**
   * إكمال خطوة
   */
  completeStep(lessonId: string, stepId: string): LessonProgress | null {
    const progress = this.userProgress.get(lessonId);
    const lesson = this.lessons.get(lessonId);

    if (!progress || !lesson) return null;

    const step = lesson.steps.find((s) => s.id === stepId);
    if (!step) return null;

    step.completed = true;
    progress.completedSteps += 1;
    progress.currentStepIndex += 1;

    if (progress.completedSteps === lesson.steps.length) {
      progress.isCompleted = true;
    }

    return progress;
  }

  /**
   * الحصول على تقدم الدرس
   */
  getLessonProgress(lessonId: string): LessonProgress | undefined {
    return this.userProgress.get(lessonId);
  }

  /**
   * الحصول على جميع الدروس المكتملة
   */
  getCompletedLessons(): Lesson[] {
    return Array.from(this.userProgress.values())
      .filter((progress) => progress.isCompleted)
      .map((progress) => this.lessons.get(progress.lessonId))
      .filter((lesson) => lesson !== undefined) as Lesson[];
  }

  /**
   * حساب نسبة الإكمال
   */
  getCompletionPercentage(lessonId: string): number {
    const progress = this.userProgress.get(lessonId);
    const lesson = this.lessons.get(lessonId);

    if (!progress || !lesson || lesson.steps.length === 0) return 0;

    return (progress.completedSteps / lesson.steps.length) * 100;
  }

  /**
   * إضافة درس مخصص
   */
  addCustomLesson(lesson: Lesson): void {
    this.lessons.set(lesson.id, lesson);
  }

  /**
   * حذف درس
   */
  deleteLesson(id: string): boolean {
    return this.lessons.delete(id);
  }
}

/**
 * واجهة تقدم الدرس
 */
export interface LessonProgress {
  lessonId: string;
  startedAt: Date;
  completedSteps: number;
  currentStepIndex: number;
  isCompleted: boolean;
}
