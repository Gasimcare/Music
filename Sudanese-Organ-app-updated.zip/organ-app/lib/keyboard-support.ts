import { Platform } from "react-native";
import { MIN_OCTAVE, MAX_OCTAVE } from "@/lib/musical-constants";
import {
  KEYBOARD_NOTE_MAP,
  KEYBOARD_INSTRUCTIONS,
  getMappedNote,
  getOctaveFromKey,
} from "@/lib/keyboard-mapping";

export type KeyboardSupportOptions = {
  getOctave: () => number;
  onNotePress: (note: string) => void;
  onNoteRelease: (note: string) => void;
  onOctaveChange: (octave: number) => void;
};

export { KEYBOARD_NOTE_MAP, KEYBOARD_INSTRUCTIONS, getMappedNote, getOctaveFromKey } from "@/lib/keyboard-mapping";

/**
 * Attach browser keyboard listeners. Native React Native does not expose a
 * global hardware-keyboard event API, so the same mapping remains exported
 * for native keyboard bridges without crashing Expo Go.
 */
export function attachKeyboardSupport(options: KeyboardSupportOptions): () => void {
  if (Platform.OS !== "web" || typeof document === "undefined") {
    return () => undefined;
  }

  const activeKeys = new Map<string, string>();

  const handleKeyDown = (event: KeyboardEvent) => {
    const key = event.key.toLowerCase();

    if (key === "[" || key === "-") {
      event.preventDefault();
      options.onOctaveChange(Math.max(MIN_OCTAVE, options.getOctave() - 1));
      return;
    }

    if (key === "]" || key === "=" || key === "+") {
      event.preventDefault();
      options.onOctaveChange(Math.min(MAX_OCTAVE, options.getOctave() + 1));
      return;
    }

    const directOctave = getOctaveFromKey(key);
    if (directOctave !== null) {
      event.preventDefault();
      options.onOctaveChange(directOctave);
      return;
    }

    const note = getMappedNote(key);
    if (!note || activeKeys.has(key)) return;

    event.preventDefault();
    const fullNote = `${note}${options.getOctave()}`;
    activeKeys.set(key, fullNote);
    options.onNotePress(fullNote);
  };

  const handleKeyUp = (event: KeyboardEvent) => {
    const key = event.key.toLowerCase();
    const fullNote = activeKeys.get(key);
    if (!fullNote) return;

    event.preventDefault();
    activeKeys.delete(key);
    options.onNoteRelease(fullNote);
  };

  const handleBlur = () => {
    for (const fullNote of activeKeys.values()) {
      options.onNoteRelease(fullNote);
    }
    activeKeys.clear();
  };

  document.addEventListener("keydown", handleKeyDown);
  document.addEventListener("keyup", handleKeyUp);
  window.addEventListener("blur", handleBlur);

  return () => {
    handleBlur();
    document.removeEventListener("keydown", handleKeyDown);
    document.removeEventListener("keyup", handleKeyUp);
    window.removeEventListener("blur", handleBlur);
  };
}
