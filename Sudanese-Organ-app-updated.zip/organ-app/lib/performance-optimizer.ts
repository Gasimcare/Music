/**
 * نظام تحسين الأداء والتخزين المؤقت
 */

export interface CachedAudio {
  frequency: number;
  buffer: AudioBuffer;
  timestamp: number;
}

export class PerformanceOptimizer {
  private audioCache: Map<string, CachedAudio> = new Map();
  private maxCacheSize = 100; // الحد الأقصى للعناصر المخزنة مؤقتاً
  private cacheTimeout = 5 * 60 * 1000; // 5 دقائق

  /**
   * الحصول على الصوت من الذاكرة المؤقتة
   */
  getFromCache(key: string): AudioBuffer | null {
    const cached = this.audioCache.get(key);
    if (!cached) return null;

    // التحقق من انتهاء صلاحية الذاكرة المؤقتة
    if (Date.now() - cached.timestamp > this.cacheTimeout) {
      this.audioCache.delete(key);
      return null;
    }

    return cached.buffer;
  }

  /**
   * حفظ الصوت في الذاكرة المؤقتة
   */
  cacheAudio(key: string, buffer: AudioBuffer, frequency: number): void {
    // إذا تجاوزنا الحد الأقصى، احذف أقدم عنصر
    if (this.audioCache.size >= this.maxCacheSize) {
      const firstKey = this.audioCache.keys().next().value;
      if (firstKey) {
        this.audioCache.delete(firstKey);
      }
    }

    this.audioCache.set(key, {
      frequency,
      buffer,
      timestamp: Date.now(),
    });
  }

  /**
   * مسح الذاكرة المؤقتة
   */
  clearCache(): void {
    this.audioCache.clear();
  }

  /**
   * الحصول على حجم الذاكرة المؤقتة
   */
  getCacheSize(): number {
    return this.audioCache.size;
  }

  /**
   * تنظيف الذاكرة المؤقتة من العناصر المنتهية الصلاحية
   */
  cleanExpiredCache(): void {
    const now = Date.now();
    const keysToDelete: string[] = [];

    this.audioCache.forEach((cached, key) => {
      if (now - cached.timestamp > this.cacheTimeout) {
        keysToDelete.push(key);
      }
    });

    keysToDelete.forEach((key) => this.audioCache.delete(key));
  }

  /**
   * قياس الأداء
   */
  measurePerformance<T>(
    fn: () => T,
    label: string
  ): { result: T; duration: number } {
    const start = performance.now();
    const result = fn();
    const duration = performance.now() - start;

    console.log(`[Performance] ${label}: ${duration.toFixed(2)}ms`);

    return { result, duration };
  }

  /**
   * تحسين استهلاك الذاكرة
   */
  optimizeMemory(): {
    cacheSize: number;
    clearedItems: number;
  } {
    const initialSize = this.audioCache.size;
    this.cleanExpiredCache();
    const finalSize = this.audioCache.size;

    return {
      cacheSize: finalSize,
      clearedItems: initialSize - finalSize,
    };
  }
}

/**
 * مثيل عام من محسّن الأداء
 */
export const performanceOptimizer = new PerformanceOptimizer();
