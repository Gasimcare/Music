import { useState, useCallback, useEffect } from "react";
import { Platform } from "react-native";
import { setAudioModeAsync } from "expo-audio";
import { InstrumentType, DEFAULT_AUDIO_SETTINGS } from "@/lib/musical-constants";
import { AudioEffectsConfig } from "@/lib/audio-effects";

interface AudioSettings extends AudioEffectsConfig {
  volume: number;
  instrument: InstrumentType;
}

export function useAudioEffects() {
  const [settings, setSettings] = useState<AudioSettings>({
    volume: DEFAULT_AUDIO_SETTINGS.volume,
    sustain: DEFAULT_AUDIO_SETTINGS.sustain,
    reverb: DEFAULT_AUDIO_SETTINGS.reverb,
    delay: 0.2,
    delayTime: 0.5,
    delayFeedback: 0.4,
    instrument: DEFAULT_AUDIO_SETTINGS.instrument,
  });

  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    const initAudio = async () => {
      try {
        if (Platform.OS !== "web") {
          await setAudioModeAsync({
            playsInSilentMode: true,
          });
        }
        setIsInitialized(true);
      } catch (error) {
        console.error("Failed to initialize audio:", error);
      }
    };

    initAudio();
  }, []);

  const updateVolume = useCallback((volume: number) => {
    setSettings((prev) => ({
      ...prev,
      volume: Math.max(0, Math.min(1, volume)),
    }));
  }, []);

  const updateReverb = useCallback((reverb: number) => {
    setSettings((prev) => ({
      ...prev,
      reverb: Math.max(0, Math.min(1, reverb)),
    }));
  }, []);

  const updateSustain = useCallback((sustain: number) => {
    setSettings((prev) => ({
      ...prev,
      sustain: Math.max(0, Math.min(1, sustain)),
    }));
  }, []);

  const updateDelay = useCallback((delay: number) => {
    setSettings((prev) => ({
      ...prev,
      delay: Math.max(0, Math.min(1, delay)),
    }));
  }, []);

  const updateDelayTime = useCallback((delayTime: number) => {
    setSettings((prev) => ({
      ...prev,
      delayTime: Math.max(0.1, Math.min(2, delayTime)),
    }));
  }, []);

  const updateDelayFeedback = useCallback((feedback: number) => {
    setSettings((prev) => ({
      ...prev,
      delayFeedback: Math.max(0, Math.min(0.9, feedback)),
    }));
  }, []);

  const updateInstrument = useCallback((instrument: InstrumentType) => {
    setSettings((prev) => ({
      ...prev,
      instrument,
    }));
  }, []);

  return {
    settings,
    isInitialized,
    updateVolume,
    updateReverb,
    updateSustain,
    updateDelay,
    updateDelayTime,
    updateDelayFeedback,
    updateInstrument,
  };
}
