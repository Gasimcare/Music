import { useCallback, useEffect, useSyncExternalStore } from "react";
import { Platform } from "react-native";
import { setAudioModeAsync } from "expo-audio";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { InstrumentType, DEFAULT_AUDIO_SETTINGS } from "@/lib/musical-constants";

export interface AudioSettings {
  volume: number;
  reverb: number;
  sustain: number;
  instrument: InstrumentType;
}

export const AUDIO_SETTINGS_STORAGE_KEY = "sudanese-organ:audio-settings:v1";

const clamp01 = (n: unknown, fallback: number) =>
  typeof n === "number" && Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : fallback;

/** Validates untrusted stored JSON and merges it onto the defaults. */
export function sanitizeAudioSettings(raw: unknown): AudioSettings {
  const d = DEFAULT_AUDIO_SETTINGS;
  const obj = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const instrument = Object.values(InstrumentType).includes(obj.instrument as InstrumentType)
    ? (obj.instrument as InstrumentType)
    : d.instrument;
  return {
    volume: clamp01(obj.volume, d.volume),
    reverb: clamp01(obj.reverb, d.reverb),
    sustain: clamp01(obj.sustain, d.sustain),
    instrument,
  };
}

/**
 * Single shared store so every screen (keyboard, settings) sees the same values,
 * persisted locally with AsyncStorage.
 */
let current: AudioSettings = { ...DEFAULT_AUDIO_SETTINGS };
let hydrated = false;
let hydrating: Promise<void> | null = null;
const listeners = new Set<() => void>();

const emit = () => listeners.forEach((l) => l());

const persist = () => {
  AsyncStorage.setItem(AUDIO_SETTINGS_STORAGE_KEY, JSON.stringify(current)).catch((e) =>
    console.warn("Failed to save audio settings:", e)
  );
};

function setSettings(patch: Partial<AudioSettings>) {
  current = sanitizeAudioSettings({ ...current, ...patch });
  emit();
  persist();
}

function hydrate(): Promise<void> {
  if (hydrated) return Promise.resolve();
  if (!hydrating) {
    hydrating = AsyncStorage.getItem(AUDIO_SETTINGS_STORAGE_KEY)
      .then((json) => {
        if (json) current = sanitizeAudioSettings(JSON.parse(json));
      })
      .catch((e) => console.warn("Failed to load audio settings:", e))
      .finally(() => {
        hydrated = true;
        emit();
      });
  }
  return hydrating;
}

const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
};
const getSnapshot = () => current;

export function useAudioPlayerSettings() {
  const settings = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
  const isInitialized = useSyncExternalStore(
    subscribe,
    () => hydrated,
    () => hydrated
  );

  useEffect(() => {
    hydrate();
    if (Platform.OS !== "web") {
      setAudioModeAsync({ playsInSilentMode: true }).catch((error) =>
        console.error("Failed to initialize audio:", error)
      );
    }
  }, []);

  const updateVolume = useCallback((volume: number) => setSettings({ volume }), []);
  const updateReverb = useCallback((reverb: number) => setSettings({ reverb }), []);
  const updateSustain = useCallback((sustain: number) => setSettings({ sustain }), []);
  const updateInstrument = useCallback(
    (instrument: InstrumentType) => setSettings({ instrument }),
    []
  );

  return {
    settings,
    isInitialized,
    updateVolume,
    updateReverb,
    updateSustain,
    updateInstrument,
  };
}
