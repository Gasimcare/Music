import React, { useCallback } from "react";
import { Pressable, View, Text, StyleSheet, Dimensions } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { cn } from "@/lib/utils";
import * as Haptics from "expo-haptics";

interface PianoKeyProps {
  note: string;
  isBlackKey: boolean;
  onPress: (note: string) => void;
  onRelease: (note: string) => void;
  isPressed?: boolean;
  width?: number;
  height?: number;
}

export function PianoKey({
  note,
  isBlackKey,
  onPress,
  onRelease,
  isPressed = false,
  width = 40,
  height = 200,
}: PianoKeyProps) {
  const colors = useColors();

  const handlePressIn = useCallback(() => {
    onPress(note);
    // تشغيل اهتزاز خفيف
    if (Haptics.ImpactFeedbackStyle) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  }, [note, onPress]);

  const handlePressOut = useCallback(() => {
    onRelease(note);
  }, [note, onRelease]);

  if (isBlackKey) {
    return (
      <Pressable
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        style={({ pressed }) => [
          styles.blackKey,
          {
            width: width * 0.6,
            height: height * 0.6,
            backgroundColor: isPressed ? "#ffd700" : "#1a1a1a",
            borderColor: isPressed ? "#ffed4e" : "#333333",
            opacity: pressed ? 0.8 : 1,
          },
        ]}
      >
        <Text
          style={[
            styles.keyLabel,
            {
              color: isPressed ? "#000" : "#888888",
              fontSize: 10,
            },
          ]}
        >
          {note}
        </Text>
      </Pressable>
    );
  }

  return (
    <Pressable
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={({ pressed }) => [
        styles.whiteKey,
        {
          width: width,
          height: height,
          backgroundColor: isPressed ? "#f0f0f0" : "#ffffff",
          borderColor: isPressed ? "#ffd700" : "#cccccc",
          opacity: pressed ? 0.9 : 1,
        },
      ]}
    >
      <Text
        style={[
          styles.keyLabel,
          {
            color: isPressed ? "#ffd700" : "#333333",
            fontSize: 12,
          },
        ]}
      >
        {note}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  whiteKey: {
    borderWidth: 1,
    borderRadius: 4,
    justifyContent: "flex-end",
    alignItems: "center",
    paddingBottom: 8,
    marginHorizontal: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  blackKey: {
    borderWidth: 1,
    borderRadius: 3,
    justifyContent: "flex-end",
    alignItems: "center",
    paddingBottom: 4,
    marginHorizontal: -12,
    zIndex: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  keyLabel: {
    fontWeight: "600",
  },
});
