import React, { useState, useCallback, useMemo } from "react";
import { View, ScrollView, StyleSheet, Text, Dimensions, Pressable } from "react-native";
import { PianoKey } from "./piano-key";
import { NOTES, WHITE_KEYS, BLACK_KEYS, DEFAULT_OCTAVE, TOTAL_OCTAVES } from "@/lib/musical-constants";
import { useColors } from "@/hooks/use-colors";

interface PianoKeyboardProps {
  onNotePress: (note: string) => void;
  onNoteRelease: (note: string) => void;
  currentOctave?: number;
  onOctaveChange?: (octave: number) => void;
}

export function PianoKeyboard({
  onNotePress,
  onNoteRelease,
  currentOctave = DEFAULT_OCTAVE,
  onOctaveChange,
}: PianoKeyboardProps) {
  const colors = useColors();
  const [pressedKeys, setPressedKeys] = useState<Set<string>>(new Set());
  const [octave, setOctave] = useState(currentOctave);
  const screenWidth = Dimensions.get("window").width;
  const keyWidth = (screenWidth - 30) / 7;

  const handleNotePress = useCallback(
    (note: string) => {
      const fullNote = `${note}${octave}`;
      setPressedKeys((prev) => new Set(prev).add(fullNote));
      onNotePress(fullNote);
    },
    [octave, onNotePress]
  );

  const handleNoteRelease = useCallback(
    (note: string) => {
      const fullNote = `${note}${octave}`;
      setPressedKeys((prev) => {
        const newSet = new Set(prev);
        newSet.delete(fullNote);
        return newSet;
      });
      onNoteRelease(fullNote);
    },
    [octave, onNoteRelease]
  );

  const handleOctaveChange = useCallback(
    (newOctave: number) => {
      if (newOctave >= 0 && newOctave < TOTAL_OCTAVES) {
        setOctave(newOctave);
        onOctaveChange?.(newOctave);
      }
    },
    [onOctaveChange]
  );

  const keyboardLayout = useMemo(() => {
    const whiteKeyPositions: Array<{ note: string; index: number }> = [];
    const blackKeyPositions: Array<{ note: string; index: number }> = [];

    WHITE_KEYS.forEach((note, index) => {
      whiteKeyPositions.push({ note, index });
    });

    BLACK_KEYS.forEach((note) => {
      const noteIndex = NOTES.indexOf(note);
      const whiteKeyBefore = WHITE_KEYS.findIndex(
        (wk) => NOTES.indexOf(wk) > noteIndex
      );
      blackKeyPositions.push({
        note,
        index: whiteKeyBefore > 0 ? whiteKeyBefore - 0.5 : 0,
      });
    });

    return { whiteKeyPositions, blackKeyPositions };
  }, []);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.octaveDisplay}>
        <Text style={[styles.octaveLabel, { color: colors.foreground }]}>
          الأوكتاف: {octave}
        </Text>
      </View>

      <View style={styles.octaveControls}>
        <Pressable
          style={[
            styles.octaveButton,
            { backgroundColor: colors.primary, opacity: octave === 0 ? 0.5 : 1 },
          ]}
          onPress={() => handleOctaveChange(octave - 1)}
          disabled={octave === 0}
        >
          <Text style={[styles.buttonText, { color: colors.background }]}>
            سابق
          </Text>
        </Pressable>
        <Pressable
          style={[
            styles.octaveButton,
            {
              backgroundColor: colors.primary,
              opacity: octave === TOTAL_OCTAVES - 1 ? 0.5 : 1,
            },
          ]}
          onPress={() => handleOctaveChange(octave + 1)}
          disabled={octave === TOTAL_OCTAVES - 1}
        >
          <Text style={[styles.buttonText, { color: colors.background }]}>
            التالي
          </Text>
        </Pressable>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.keyboardScroll}
        contentContainerStyle={styles.keyboardContent}
      >
        <View style={styles.keyboard}>
          <View style={styles.whiteKeysContainer}>
            {keyboardLayout.whiteKeyPositions.map(({ note }) => (
              <PianoKey
                key={`white-${note}`}
                note={note}
                isBlackKey={false}
                onPress={handleNotePress}
                onRelease={handleNoteRelease}
                isPressed={pressedKeys.has(`${note}${octave}`)}
                width={keyWidth}
                height={200}
              />
            ))}
          </View>

          <View style={styles.blackKeysContainer}>
            {keyboardLayout.blackKeyPositions.map(({ note, index }) => (
              <View
                key={`black-${note}`}
                style={[
                  styles.blackKeyWrapper,
                  { left: index * keyWidth + keyWidth * 0.7 },
                ]}
              >
                <PianoKey
                  note={note}
                  isBlackKey={true}
                  onPress={handleNotePress}
                  onRelease={handleNoteRelease}
                  isPressed={pressedKeys.has(`${note}${octave}`)}
                  width={keyWidth}
                  height={200}
                />
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingVertical: 16,
  },
  octaveDisplay: {
    alignItems: "center",
    paddingVertical: 12,
  },
  octaveLabel: {
    fontSize: 18,
    fontWeight: "bold",
  },
  octaveControls: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 12,
  },
  octaveButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonText: {
    fontSize: 14,
    fontWeight: "600",
  },
  keyboardScroll: {
    flex: 1,
  },
  keyboardContent: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  keyboard: {
    position: "relative",
    height: 200,
  },
  whiteKeysContainer: {
    flexDirection: "row",
    height: 200,
  },
  blackKeysContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 120,
    flexDirection: "row",
  },
  blackKeyWrapper: {
    position: "absolute",
    height: 120,
    justifyContent: "flex-start",
  },
});
