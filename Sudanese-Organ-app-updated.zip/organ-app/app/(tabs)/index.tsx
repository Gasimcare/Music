import { useState, useCallback, useEffect, useRef } from "react";
import { View, ScrollView, Text, Pressable, StyleSheet } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { PianoKeyboard } from "@/components/piano-keyboard";
import { useColors } from "@/hooks/use-colors";
import { useAudioPlayerSettings } from "@/hooks/use-audio-player";
import { playNote, stopNote, setMasterVolume } from "@/lib/audio-generator";
import { DEFAULT_OCTAVE, MIN_OCTAVE, MAX_OCTAVE } from "@/lib/musical-constants";
import { attachKeyboardSupport, KEYBOARD_INSTRUCTIONS } from "@/lib/keyboard-support";
import { router } from "expo-router";

export default function HomeScreen() {
  const colors = useColors();
  const audioSettings = useAudioPlayerSettings();
  const [currentOctave, setCurrentOctave] = useState(DEFAULT_OCTAVE);
  const currentOctaveRef = useRef(currentOctave);

  currentOctaveRef.current = currentOctave;

  // تحديث مستوى الصوت عند تغييره
  useEffect(() => {
    setMasterVolume(audioSettings.settings.volume);
  }, [audioSettings.settings.volume]);

  const handleNotePress = useCallback(
    (note: string) => {
      playNote(
        note,
        2000,
        audioSettings.settings.instrument,
        audioSettings.settings.volume
      );
    },
    [audioSettings.settings.instrument, audioSettings.settings.volume]
  );

  const handleNoteRelease = useCallback((note: string) => {
    stopNote(note);
  }, []);

  const handleOctaveChange = useCallback((octave: number) => {
    if (octave >= MIN_OCTAVE && octave <= MAX_OCTAVE) {
      setCurrentOctave(octave);
    }
  }, []);

  const handlePreviousOctave = useCallback(() => {
    handleOctaveChange(currentOctave - 1);
  }, [currentOctave, handleOctaveChange]);

  const handleNextOctave = useCallback(() => {
    handleOctaveChange(currentOctave + 1);
  }, [currentOctave, handleOctaveChange]);

  useEffect(() => {
    return attachKeyboardSupport({
      getOctave: () => currentOctaveRef.current,
      onNotePress: handleNotePress,
      onNoteRelease: handleNoteRelease,
      onOctaveChange: handleOctaveChange,
    });
  }, [handleNotePress, handleNoteRelease, handleOctaveChange]);

  const handleSettingsPress = useCallback(() => {
    router.push("./settings");
  }, []);

  return (
    <ScreenContainer className="flex-1 bg-background">
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.foreground }]}>
          Sudanese Organ
        </Text>
        <Pressable
          style={[styles.settingsButton, { backgroundColor: colors.primary }]}
          onPress={handleSettingsPress}
        >
          <Text style={[styles.settingsButtonText, { color: colors.background }]}>
            ⚙️ الإعدادات
          </Text>
        </Pressable>
      </View>

      {/* عرض الأوكتاف الحالي والتنقل */}
      <View style={[styles.octaveControl, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Pressable
          style={[
            styles.octaveButton,
            {
              backgroundColor:
                currentOctave <= MIN_OCTAVE ? colors.muted : colors.primary,
            },
          ]}
          onPress={handlePreviousOctave}
          disabled={currentOctave <= MIN_OCTAVE}
        >
          <Text style={[styles.octaveButtonText, { color: colors.background }]}>
            ◀
          </Text>
        </Pressable>

        <View style={styles.octaveDisplay}>
          <Text style={[styles.octaveLabel, { color: colors.foreground }]}>
            الأوكتاف: {currentOctave}
          </Text>
          <Text style={[styles.octaveRange, { color: colors.muted }]}>
            ({MIN_OCTAVE} - {MAX_OCTAVE})
          </Text>
        </View>

        <Pressable
          style={[
            styles.octaveButton,
            {
              backgroundColor:
                currentOctave >= MAX_OCTAVE ? colors.muted : colors.primary,
            },
          ]}
          onPress={handleNextOctave}
          disabled={currentOctave >= MAX_OCTAVE}
        >
          <Text style={[styles.octaveButtonText, { color: colors.background }]}>
            ▶
          </Text>
        </Pressable>
      </View>

      <View style={[styles.keyboardHint, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.keyboardHintTitle, { color: colors.foreground }]}>لوحة مفاتيح الكمبيوتر</Text>
        <Text style={[styles.keyboardHintText, { color: colors.muted }]}>
          {KEYBOARD_INSTRUCTIONS} · [ / ] لتغيير الأوكتاف · 0–9 للانتقال المباشر
        </Text>
      </View>

      <View style={styles.container}>
        <PianoKeyboard
          onNotePress={handleNotePress}
          onNoteRelease={handleNoteRelease}
          currentOctave={currentOctave}
          onOctaveChange={handleOctaveChange}
        />
      </View>

      <View style={[styles.volumeControl, { borderTopColor: colors.border }]}>
        <Text style={[styles.volumeLabel, { color: colors.foreground }]}>
          مستوى الصوت: {Math.round(audioSettings.settings.volume * 100)}%
        </Text>
        <View style={styles.volumeSliderContainer}>
          <Pressable
            style={[styles.volumeButton, { backgroundColor: colors.primary }]}
            onPress={() =>
              audioSettings.updateVolume(
                Math.max(0, audioSettings.settings.volume - 0.1)
              )
            }
          >
            <Text style={[styles.volumeButtonText, { color: colors.background }]}>
              −
            </Text>
          </Pressable>
          <View
            style={[
              styles.volumeBar,
              {
                backgroundColor: colors.surface,
                width: audioSettings.settings.volume * 200,
              },
            ]}
          />
          <Pressable
            style={[styles.volumeButton, { backgroundColor: colors.primary }]}
            onPress={() =>
              audioSettings.updateVolume(
                Math.min(1, audioSettings.settings.volume + 0.1)
              )
            }
          >
            <Text style={[styles.volumeButtonText, { color: colors.background }]}>
              +
            </Text>
          </Pressable>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    flex: 1,
  },
  settingsButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  settingsButtonText: {
    fontSize: 14,
    fontWeight: "600",
  },
  octaveControl: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: 16,
    marginVertical: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    gap: 12,
  },
  octaveButton: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  octaveButtonText: {
    fontSize: 18,
    fontWeight: "bold",
  },
  octaveDisplay: {
    flex: 1,
    alignItems: "center",
  },
  octaveLabel: {
    fontSize: 16,
    fontWeight: "bold",
  },
  octaveRange: {
    fontSize: 12,
  },
  keyboardHint: {
    marginHorizontal: 16,
    marginBottom: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
  },
  keyboardHintTitle: {
    fontSize: 13,
    fontWeight: "700",
    textAlign: "center",
  },
  keyboardHintText: {
    fontSize: 11,
    textAlign: "center",
    marginTop: 3,
  },
  container: {
    flex: 1,
  },
  volumeControl: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderTopWidth: 1,
  },
  volumeLabel: {
    fontSize: 14,
    fontWeight: "600",
    marginBottom: 8,
  },
  volumeSliderContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  volumeButton: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  volumeButtonText: {
    fontSize: 20,
    fontWeight: "bold",
  },
  volumeBar: {
    height: 8,
    borderRadius: 4,
    flex: 1,
  },
});
