import { useState, useCallback, useMemo } from "react";
import { View, ScrollView, Text, Pressable, StyleSheet, FlatList, TextInput } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { stylesSystem } from "@/lib/styles-system";
import { instrumentsSystem } from "@/lib/instruments-system";

type TabType = "styles" | "instruments";

export default function LibraryScreen() {
  const colors = useColors();
  const [activeTab, setActiveTab] = useState<TabType>("styles");
  const [searchQuery, setSearchQuery] = useState("");
  const [refreshKey, setRefreshKey] = useState(0);

  const topStyles = useMemo(() => stylesSystem.getTopStyles(20), [refreshKey]);
  const topInstruments = useMemo(() => instrumentsSystem.getTopInstruments(20), [refreshKey]);

  const filteredData = useMemo(() => {
    if (activeTab === "styles") {
      return searchQuery
        ? stylesSystem.searchStyles(searchQuery)
        : topStyles;
    } else {
      return searchQuery
        ? instrumentsSystem.searchInstruments(searchQuery)
        : topInstruments;
    }
  }, [activeTab, searchQuery, topStyles, topInstruments, refreshKey]);

  const handleRefresh = useCallback(() => {
    setRefreshKey((prev) => prev + 1);
  }, []);

  const handleToggleFavorite = useCallback(
    (id: string) => {
      if (activeTab === "styles") {
        if (stylesSystem.isFavorite(id)) {
          stylesSystem.removeFromFavorites(id);
        } else {
          stylesSystem.addToFavorites(id);
        }
      } else {
        if (instrumentsSystem.isFavorite(id)) {
          instrumentsSystem.removeFromFavorites(id);
        } else {
          instrumentsSystem.addToFavorites(id);
        }
      }
      setRefreshKey((prev) => prev + 1);
    },
    [activeTab]
  );

  const renderStyleItem = ({ item }: { item: any }) => (
    <View style={[libraryStyles.itemCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={libraryStyles.itemHeader}>
        <View style={libraryStyles.itemInfo}>
          <Text style={[libraryStyles.itemName, { color: colors.foreground }]}>{item.name}</Text>
          <Text style={[libraryStyles.itemCategory, { color: colors.muted }]}>{item.category}</Text>
        </View>
        <Pressable
          style={[
            libraryStyles.favoriteButton,
            {
              backgroundColor: stylesSystem.isFavorite(item.id)
                ? colors.primary
                : colors.muted,
            },
          ]}
          onPress={() => handleToggleFavorite(item.id)}
        >
          <Text style={libraryStyles.favoriteIcon}>
            {stylesSystem.isFavorite(item.id) ? "★" : "☆"}
          </Text>
        </Pressable>
      </View>
      <Text style={[libraryStyles.itemDescription, { color: colors.muted }]}>
        {item.description}
      </Text>
      <View style={libraryStyles.itemFooter}>
        <Text style={[libraryStyles.itemBPM, { color: colors.foreground }]}>
          {item.bpm} BPM
        </Text>
        <Text style={[libraryStyles.itemRating, { color: colors.primary }]}>
          ⭐ {item.rating.toFixed(1)}
        </Text>
        <Text style={[libraryStyles.itemDownloads, { color: colors.muted }]}>
          📥 {item.downloads}
        </Text>
      </View>
    </View>
  );

  const renderInstrumentItem = ({ item }: { item: any }) => (
    <View style={[libraryStyles.itemCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={libraryStyles.itemHeader}>
        <View style={libraryStyles.itemInfo}>
          <Text style={[libraryStyles.itemName, { color: colors.foreground }]}>{item.name}</Text>
          <Text style={[libraryStyles.itemCategory, { color: colors.muted }]}>{item.category}</Text>
        </View>
        <Pressable
          style={[
            libraryStyles.favoriteButton,
            {
              backgroundColor: instrumentsSystem.isFavorite(item.id)
                ? colors.primary
                : colors.muted,
            },
          ]}
          onPress={() => handleToggleFavorite(item.id)}
        >
          <Text style={libraryStyles.favoriteIcon}>
            {instrumentsSystem.isFavorite(item.id) ? "★" : "☆"}
          </Text>
        </Pressable>
      </View>
      <Text style={[libraryStyles.itemDescription, { color: colors.muted }]}>
        {item.description}
      </Text>
      <View style={libraryStyles.itemFooter}>
        <Text style={[libraryStyles.itemRating, { color: colors.primary }]}>
          ⭐ {item.rating.toFixed(1)}
        </Text>
        <Text style={[libraryStyles.itemDownloads, { color: colors.muted }]}>
          📥 {item.downloads}
        </Text>
      </View>
    </View>
  );

  return (
    <ScreenContainer className="flex-1 bg-background">
      <View style={libraryStyles.header}>
        <Text style={[libraryStyles.title, { color: colors.foreground }]}>
          مكتبة الأنماط والآلات
        </Text>
        <Pressable
          style={[libraryStyles.refreshButton, { backgroundColor: colors.primary }]}
          onPress={handleRefresh}
        >
          <Text style={[libraryStyles.refreshButtonText, { color: colors.background }]}>
            ↻
          </Text>
        </Pressable>
      </View>

      {/* علامات التبويب */}
      <View style={[libraryStyles.tabsContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Pressable
          style={[
            libraryStyles.tab,
            {
              backgroundColor: activeTab === "styles" ? colors.primary : "transparent",
            },
          ]}
          onPress={() => setActiveTab("styles")}
        >
          <Text
            style={[
              libraryStyles.tabText,
              {
                color: activeTab === "styles" ? colors.background : colors.foreground,
              },
            ]}
          >
            الأنماط
          </Text>
        </Pressable>
        <Pressable
          style={[
            libraryStyles.tab,
            {
              backgroundColor: activeTab === "instruments" ? colors.primary : "transparent",
            },
          ]}
          onPress={() => setActiveTab("instruments")}
        >
          <Text
            style={[
              libraryStyles.tabText,
              {
                color: activeTab === "instruments" ? colors.background : colors.foreground,
              },
            ]}
          >
            الآلات
          </Text>
        </Pressable>
      </View>

      {/* شريط البحث */}
      <View style={[libraryStyles.searchContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <TextInput
          style={[libraryStyles.searchInput, { color: colors.foreground }]}
          placeholder="ابحث..."
          placeholderTextColor={colors.muted}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* قائمة العناصر */}
      <FlatList
        data={filteredData}
        renderItem={activeTab === "styles" ? renderStyleItem : renderInstrumentItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={libraryStyles.listContent}
        ItemSeparatorComponent={() => (
          <View style={[libraryStyles.separator, { backgroundColor: colors.border }]} />
        )}
        ListEmptyComponent={
          <View style={[libraryStyles.emptyState, { backgroundColor: colors.surface }]}>
            <Text style={[libraryStyles.emptyStateText, { color: colors.muted }]}>
              لا توجد نتائج
            </Text>
          </View>
        }
      />
    </ScreenContainer>
  );
}

const libraryStyles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    flex: 1,
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  refreshButtonText: {
    fontSize: 18,
    fontWeight: "bold",
  },
  tabsContainer: {
    flexDirection: "row",
    marginHorizontal: 16,
    marginVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 6,
    alignItems: "center",
  },
  tabText: {
    fontSize: 14,
    fontWeight: "600",
  },
  searchContainer: {
    marginHorizontal: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
  },
  searchInput: {
    height: 40,
    fontSize: 14,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  itemCard: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    gap: 8,
  },
  itemHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  itemInfo: {
    flex: 1,
    gap: 4,
  },
  itemName: {
    fontSize: 16,
    fontWeight: "bold",
  },
  itemCategory: {
    fontSize: 12,
  },
  favoriteButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
  },
  favoriteIcon: {
    fontSize: 18,
  },
  itemDescription: {
    fontSize: 12,
  },
  itemFooter: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 8,
  },
  itemBPM: {
    fontSize: 12,
    fontWeight: "600",
  },
  itemRating: {
    fontSize: 12,
    fontWeight: "600",
  },
  itemDownloads: {
    fontSize: 12,
  },
  separator: {
    height: 1,
    marginVertical: 8,
  },
  emptyState: {
    borderRadius: 8,
    padding: 24,
    alignItems: "center",
  },
  emptyStateText: {
    fontSize: 14,
  },
});
