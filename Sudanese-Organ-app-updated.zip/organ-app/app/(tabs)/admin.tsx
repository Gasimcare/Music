import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { adminDashboard } from "@/lib/admin-dashboard";
import { useState } from "react";
import { useColors } from "@/hooks/use-colors";

export default function AdminScreen() {
  const colors = useColors();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [dashboardData, setDashboardData] = useState<any>(null);

  const handleAuthenticate = () => {
    const result = adminDashboard.authenticate(password);
    if (result) {
      setIsAuthenticated(true);
      const summary = adminDashboard.getDashboardSummary();
      setDashboardData(summary);
    } else {
      alert("كلمة المرور غير صحيحة");
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setPassword("");
    setDashboardData(null);
  };

  const handleGenerateDailyReport = () => {
    const reportId = adminDashboard.generateDailyReport();
    alert(`تم إنشاء التقرير اليومي: ${reportId}`);
  };

  const handleGenerateWeeklyReport = () => {
    const reportId = adminDashboard.generateWeeklyReport();
    alert(`تم إنشاء التقرير الأسبوعي: ${reportId}`);
  };

  const handleGenerateMonthlyReport = () => {
    const reportId = adminDashboard.generateMonthlyReport();
    alert(`تم إنشاء التقرير الشهري: ${reportId}`);
  };

  const handleExportJSON = () => {
    const data = adminDashboard.exportAsJSON();
    console.log("Exported JSON:", data);
    alert("تم تصدير البيانات كـ JSON");
  };

  const handleExportCSV = () => {
    const data = adminDashboard.exportAsCSV();
    console.log("Exported CSV:", data);
    alert("تم تصدير البيانات كـ CSV");
  };

  if (!isAuthenticated) {
    return (
      <ScreenContainer className="p-6 justify-center">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
          <View className="flex-1 gap-6 justify-center">
            {/* Header */}
            <View className="items-center gap-2 mb-4">
              <Text className="text-3xl font-bold text-foreground">لوحة التحكم</Text>
              <Text className="text-sm text-muted">إدارة التطبيق والإحصائيات</Text>
            </View>

            {/* Login Card */}
            <View className="bg-surface rounded-2xl p-6 gap-4 border border-border">
              <Text className="text-lg font-semibold text-foreground">تسجيل الدخول</Text>

              {/* Password Input */}
              <View className="gap-2">
                <Text className="text-sm font-medium text-muted">كلمة المرور</Text>
                <View
                  className="border border-border rounded-lg px-4 py-3 flex-row items-center gap-2"
                  style={{ backgroundColor: colors.background }}
                >
                  <Text
                    className="flex-1 text-foreground"
                    selectable={false}
                  >
                    {showPassword ? password : "•".repeat(password.length)}
                  </Text>
                  <Pressable
                    onPress={() => setShowPassword(!showPassword)}
                    style={({ pressed }) => [
                      { opacity: pressed ? 0.7 : 1 },
                    ]}
                  >
                    <Text className="text-primary text-sm font-medium">
                      {showPassword ? "إخفاء" : "إظهار"}
                    </Text>
                  </Pressable>
                </View>
              </View>

              {/* Login Button */}
              <Pressable
                onPress={handleAuthenticate}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.primary,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                className="rounded-lg py-3 items-center"
              >
                <Text className="text-background font-semibold">دخول</Text>
              </Pressable>
            </View>

            {/* Info */}
            <View className="bg-warning/10 rounded-lg p-4 gap-2">
              <Text className="text-sm font-medium text-warning">ملاحظة</Text>
              <Text className="text-xs text-muted">
                هذه لوحة التحكم مخصصة للمسؤولين فقط. يرجى عدم مشاركة كلمة المرور.
              </Text>
            </View>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="gap-6">
          {/* Header */}
          <View className="flex-row justify-between items-center">
            <View className="gap-1">
              <Text className="text-2xl font-bold text-foreground">لوحة التحكم</Text>
              <Text className="text-xs text-muted">
                آخر تحديث: {new Date().toLocaleTimeString("ar-SA")}
              </Text>
            </View>
            <Pressable
              onPress={handleLogout}
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              className="bg-error/20 rounded-lg px-3 py-2"
            >
              <Text className="text-error text-sm font-medium">خروج</Text>
            </Pressable>
          </View>

          {/* Metrics */}
          {dashboardData && (
            <View className="gap-3">
              <Text className="text-lg font-semibold text-foreground">الإحصائيات الرئيسية</Text>
              <View className="flex-row gap-3 flex-wrap">
                <View className="flex-1 min-w-[45%] bg-surface rounded-lg p-4 gap-1 border border-border">
                  <Text className="text-xs text-muted">إجمالي المستخدمين</Text>
                  <Text className="text-2xl font-bold text-primary">
                    {dashboardData.metrics.totalUsers}
                  </Text>
                </View>
                <View className="flex-1 min-w-[45%] bg-surface rounded-lg p-4 gap-1 border border-border">
                  <Text className="text-xs text-muted">المستخدمون النشطون</Text>
                  <Text className="text-2xl font-bold text-success">
                    {dashboardData.metrics.activeUsers}
                  </Text>
                </View>
                <View className="flex-1 min-w-[45%] bg-surface rounded-lg p-4 gap-1 border border-border">
                  <Text className="text-xs text-muted">إجمالي الجلسات</Text>
                  <Text className="text-2xl font-bold text-primary">
                    {dashboardData.metrics.totalSessions}
                  </Text>
                </View>
                <View className="flex-1 min-w-[45%] bg-surface rounded-lg p-4 gap-1 border border-border">
                  <Text className="text-xs text-muted">ضغطات المفاتيح</Text>
                  <Text className="text-2xl font-bold text-warning">
                    {dashboardData.metrics.totalKeyPresses}
                  </Text>
                </View>
              </View>
            </View>
          )}

          {/* Reports Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">التقارير</Text>
            <View className="gap-2">
              <Pressable
                onPress={handleGenerateDailyReport}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.primary,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                className="rounded-lg py-3 items-center"
              >
                <Text className="text-background font-semibold">التقرير اليومي</Text>
              </Pressable>
              <Pressable
                onPress={handleGenerateWeeklyReport}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.primary,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                className="rounded-lg py-3 items-center"
              >
                <Text className="text-background font-semibold">التقرير الأسبوعي</Text>
              </Pressable>
              <Pressable
                onPress={handleGenerateMonthlyReport}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.primary,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                className="rounded-lg py-3 items-center"
              >
                <Text className="text-background font-semibold">التقرير الشهري</Text>
              </Pressable>
            </View>
          </View>

          {/* Export Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">تصدير البيانات</Text>
            <View className="gap-2">
              <Pressable
                onPress={handleExportJSON}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.surface,
                    borderColor: colors.primary,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                className="rounded-lg py-3 items-center border"
              >
                <Text className="text-primary font-semibold">تصدير كـ JSON</Text>
              </Pressable>
              <Pressable
                onPress={handleExportCSV}
                style={({ pressed }) => [
                  {
                    backgroundColor: colors.surface,
                    borderColor: colors.primary,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                className="rounded-lg py-3 items-center border"
              >
                <Text className="text-primary font-semibold">تصدير كـ CSV</Text>
              </Pressable>
            </View>
          </View>

          {/* Footer */}
          <View className="bg-surface rounded-lg p-4 gap-2 border border-border">
            <Text className="text-xs font-medium text-muted">معلومات النظام</Text>
            <Text className="text-xs text-muted">الإصدار: {dashboardData?.metrics.appVersion}</Text>
            <Text className="text-xs text-muted">
              آخر تحديث: {new Date(dashboardData?.metrics.lastUpdated).toLocaleString("ar-SA")}
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
