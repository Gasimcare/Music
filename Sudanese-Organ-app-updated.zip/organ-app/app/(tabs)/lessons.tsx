import { useState, useCallback } from "react";
import { View, ScrollView, Text, Pressable, StyleSheet, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { LessonsSystem, Lesson } from "@/lib/lessons-system";

export default function LessonsScreen() {
  const colors = useColors();
  const [lessonsSystem] = useState(() => new LessonsSystem());
  const [lessons, setLessons] = useState<Lesson[]>(lessonsSystem.getAllLessons());
  const [selectedLevel, setSelectedLevel] = useState<"beginner" | "intermediate" | "advanced">("beginner");

  const filteredLessons = lessons.filter((lesson) => lesson.level === selectedLevel);

  const handleStartLesson = useCallback(
    (lessonId: string) => {
      lessonsSystem.startLesson(lessonId);
      // يمكن إضافة التنقل إلى شاشة الدرس هنا
    },
    [lessonsSystem]
  );

  const getLevelLabel = (level: string) => {
    switch (level) {
      case "beginner":
        return "مبتدئ";
      case "intermediate":
        return "متوسط";
      case "advanced":
        return "متقدم";
      default:
        return level;
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case "beginner":
        return colors.success;
      case "intermediate":
        return colors.warning;
      case "advanced":
        return colors.error;
      default:
        return colors.primary;
    }
  };

  const renderLessonItem = ({ item }: { item: Lesson }) => (
    <View style={[styles.lessonCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.lessonHeader}>
        <View style={styles.lessonInfo}>
          <Text style={[styles.lessonTitle, { color: colors.foreground }]}>
            {item.title}
          </Text>
          <Text style={[styles.lessonDescription, { color: colors.muted }]}>
            {item.description}
          </Text>
        </View>
        <View
          style={[
            styles.levelBadge,
            { backgroundColor: getLevelColor(item.level) },
          ]}
        >
          <Text style={[styles.levelText, { color: colors.background }]}>
            {getLevelLabel(item.level)}
          </Text>
        </View>
      </View>

      <View style={styles.lessonMeta}>
        <Text style={[styles.metaText, { color: colors.muted }]}>
          ⏱ {item.duration} دقيقة
        </Text>
        <Text style={[styles.metaText, { color: colors.muted }]}>
          📚 {item.steps.length} خطوات
        </Text>
      </View>

      <Pressable
        style={[styles.startButton, { backgroundColor: colors.primary }]}
        onPress={() => handleStartLesson(item.id)}
      >
        <Text style={[styles.startButtonText, { color: colors.background }]}>
          ابدأ الدرس
        </Text>
      </Pressable>
    </View>
  );

  return (
    <ScreenContainer className="flex-1 bg-background">
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.foreground }]}>
          الدروس الموسيقية
        </Text>
      </View>

      {/* مرشح المستويات */}
      <View style={styles.filterContainer}>
        {(["beginner", "intermediate", "advanced"] as const).map((level) => (
          <Pressable
            key={level}
            style={[
              styles.filterButton,
              {
                backgroundColor:
                  selectedLevel === level ? colors.primary : colors.surface,
                borderColor: colors.border,
              },
            ]}
            onPress={() => setSelectedLevel(level)}
          >
            <Text
              style={[
                styles.filterButtonText,
                {
                  color:
                    selectedLevel === level ? colors.background : colors.foreground,
                },
              ]}
            >
              {getLevelLabel(level)}
            </Text>
          </Pressable>
        ))}
      </View>

      <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
        {filteredLessons.length === 0 ? (
          <View style={[styles.emptyState, { backgroundColor: colors.surface }]}>
            <Text style={[styles.emptyStateText, { color: colors.muted }]}>
              لا توجد دروس في هذا المستوى حالياً
            </Text>
          </View>
        ) : (
          <FlatList
            scrollEnabled={false}
            data={filteredLessons}
            renderItem={renderLessonItem}
            keyExtractor={(item) => item.id}
            ItemSeparatorComponent={() => (
              <View style={[styles.separator, { backgroundColor: colors.border }]} />
            )}
          />
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  filterContainer: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: "center",
  },
  filterButtonText: {
    fontSize: 12,
    fontWeight: "600",
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  lessonCard: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  lessonHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: 12,
  },
  lessonInfo: {
    flex: 1,
    gap: 4,
  },
  lessonTitle: {
    fontSize: 16,
    fontWeight: "bold",
  },
  lessonDescription: {
    fontSize: 12,
    lineHeight: 16,
  },
  levelBadge: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 4,
  },
  levelText: {
    fontSize: 11,
    fontWeight: "600",
  },
  lessonMeta: {
    flexDirection: "row",
    gap: 12,
  },
  metaText: {
    fontSize: 12,
  },
  startButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: "center",
  },
  startButtonText: {
    fontSize: 14,
    fontWeight: "600",
  },
  emptyState: {
    borderRadius: 8,
    padding: 24,
    alignItems: "center",
  },
  emptyStateText: {
    fontSize: 14,
  },
  separator: {
    height: 1,
    marginVertical: 8,
  },
});
