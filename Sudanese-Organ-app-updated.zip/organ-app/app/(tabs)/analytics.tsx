import { useState, useCallback, useMemo } from "react";
import { View, ScrollView, Text, Pressable, StyleSheet, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { analyticsSystem } from "@/lib/analytics-system";

export default function AnalyticsScreen() {
  const colors = useColors();
  const [refreshKey, setRefreshKey] = useState(0);

  const stats = useMemo(() => analyticsSystem.getAppStatistics(), [refreshKey]);
  const noteStats = useMemo(() => analyticsSystem.getTopNotes(5), [refreshKey]);
  const progress = useMemo(() => analyticsSystem.getUserProgress(), [refreshKey]);

  const handleRefresh = useCallback(() => {
    setRefreshKey((prev) => prev + 1);
  }, []);

  const renderStatCard = (label: string, value: string | number, color: string) => (
    <View style={[styles.statCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <Text style={[styles.statLabel, { color: colors.muted }]}>{label}</Text>
      <Text style={[styles.statValue, { color }]}>{value}</Text>
    </View>
  );

  const renderNoteItem = ({ item, index }: { item: any; index: number }) => (
    <View style={[styles.noteItem, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.noteRank}>
        <Text style={[styles.rankText, { color: colors.primary }]}>#{index + 1}</Text>
      </View>
      <View style={styles.noteInfo}>
        <Text style={[styles.noteName, { color: colors.foreground }]}>
          {item.noteName}
        </Text>
        <Text style={[styles.noteFrequency, { color: colors.muted }]}>
          {item.frequency.toFixed(2)} Hz
        </Text>
      </View>
      <View style={styles.noteStats}>
        <Text style={[styles.notePlayCount, { color: colors.primary }]}>
          {item.timesPlayed}x
        </Text>
      </View>
    </View>
  );

  return (
    <ScreenContainer className="flex-1 bg-background">
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.foreground }]}>
          الإحصائيات والتحليلات
        </Text>
        <Pressable
          style={[styles.refreshButton, { backgroundColor: colors.primary }]}
          onPress={handleRefresh}
        >
          <Text style={[styles.refreshButtonText, { color: colors.background }]}>
            ↻
          </Text>
        </Pressable>
      </View>

      <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
        {/* مستوى المستخدم والتقدم */}
        <View style={[styles.progressSection, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            مستوى المستخدم
          </Text>
          <Text style={[styles.levelBadge, { color: colors.primary }]}>
            {progress.level === "beginner" && "🟢 مبتدئ"}
            {progress.level === "intermediate" && "🟡 متوسط"}
            {progress.level === "advanced" && "🔴 متقدم"}
          </Text>
          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                {
                  backgroundColor: colors.primary,
                  width: `${progress.progress}%`,
                },
              ]}
            />
          </View>
          <Text style={[styles.progressText, { color: colors.muted }]}>
            {progress.progress.toFixed(1)}% - الهدف التالي: {progress.nextMilestone} نغمة
          </Text>
        </View>

        {/* الإحصائيات الرئيسية */}
        <View>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            الإحصائيات الرئيسية
          </Text>
          <View style={styles.statsGrid}>
            {renderStatCard("إجمالي الجلسات", stats.totalSessions, colors.primary)}
            {renderStatCard("النغمات المعزوفة", stats.totalNotesPlayed, colors.success)}
            {renderStatCard(
              "وقت التسجيل",
              `${Math.round(stats.totalRecordingTime / 1000)}s`,
              colors.warning
            )}
            {renderStatCard(
              "متوسط الجلسة",
              `${stats.averageSessionDuration.toFixed(1)}s`,
              colors.primary
            )}
          </View>
        </View>

        {/* أكثر النغمات عزفاً */}
        <View>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            أكثر النغمات عزفاً
          </Text>
          {noteStats.length === 0 ? (
            <View style={[styles.emptyState, { backgroundColor: colors.surface }]}>
              <Text style={[styles.emptyStateText, { color: colors.muted }]}>
                لا توجد بيانات حتى الآن
              </Text>
            </View>
          ) : (
            <FlatList
              scrollEnabled={false}
              data={noteStats}
              renderItem={renderNoteItem}
              keyExtractor={(item) => item.noteName}
              ItemSeparatorComponent={() => (
                <View style={[styles.separator, { backgroundColor: colors.border }]} />
              )}
            />
          )}
        </View>

        {/* النغمة الأكثر عزفاً */}
        {stats.mostPlayedNote && (
          <View style={[styles.highlightCard, { backgroundColor: colors.primary }]}>
            <Text style={[styles.highlightLabel, { color: colors.background }]}>
              النغمة المفضلة
            </Text>
            <Text style={[styles.highlightValue, { color: colors.background }]}>
              {stats.mostPlayedNote}
            </Text>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    flex: 1,
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  refreshButtonText: {
    fontSize: 18,
    fontWeight: "bold",
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 16,
  },
  progressSection: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
  },
  levelBadge: {
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
  },
  progressBar: {
    height: 8,
    borderRadius: 4,
    backgroundColor: "#e0e0e0",
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
    textAlign: "center",
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: "45%",
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    alignItems: "center",
    gap: 8,
  },
  statLabel: {
    fontSize: 12,
  },
  statValue: {
    fontSize: 20,
    fontWeight: "bold",
  },
  noteItem: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    gap: 12,
  },
  noteRank: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  rankText: {
    fontSize: 14,
    fontWeight: "bold",
  },
  noteInfo: {
    flex: 1,
    gap: 4,
  },
  noteName: {
    fontSize: 14,
    fontWeight: "bold",
  },
  noteFrequency: {
    fontSize: 12,
  },
  noteStats: {
    alignItems: "center",
  },
  notePlayCount: {
    fontSize: 16,
    fontWeight: "bold",
  },
  emptyState: {
    borderRadius: 8,
    padding: 24,
    alignItems: "center",
  },
  emptyStateText: {
    fontSize: 14,
  },
  separator: {
    height: 1,
    marginVertical: 8,
  },
  highlightCard: {
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    gap: 8,
  },
  highlightLabel: {
    fontSize: 14,
    fontWeight: "600",
  },
  highlightValue: {
    fontSize: 28,
    fontWeight: "bold",
  },
});
