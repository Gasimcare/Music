import { useState, useCallback } from "react";
import { View, ScrollView, Text, Pressable, StyleSheet } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAudioPlayerSettings } from "@/hooks/use-audio-player";
import { InstrumentType } from "@/lib/musical-constants";
import { router } from "expo-router";
import { useThemeContext } from "@/lib/theme-provider";

export default function SettingsScreen() {
  const colors = useColors();
  const audioSettings = useAudioPlayerSettings();
  const { colorScheme, setColorScheme } = useThemeContext();

  const handleBackPress = useCallback(() => {
    router.back();
  }, []);

  const handleInstrumentChange = useCallback(
    (instrument: InstrumentType) => {
      audioSettings.updateInstrument(instrument);
    },
    [audioSettings]
  );

  const handleReverbChange = useCallback(
    (reverb: number) => {
      audioSettings.updateReverb(reverb);
    },
    [audioSettings]
  );

  const handleSustainChange = useCallback(
    (sustain: number) => {
      audioSettings.updateSustain(sustain);
    },
    [audioSettings]
  );

  return (
    <ScreenContainer className="flex-1 bg-background">
      <View style={styles.header}>
        <Pressable onPress={handleBackPress} style={styles.backButton}>
          <Text style={[styles.backButtonText, { color: colors.primary }]}>
            ← العودة
          </Text>
        </Pressable>
        <Text style={[styles.title, { color: colors.foreground }]}>
          Settings
        </Text>
      </View>

      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.contentContainer}
      >
        {/* اختيار الآلة الموسيقية */}
        <View
          style={[
            styles.section,
            { borderColor: colors.border, backgroundColor: colors.surface },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            الآلة الموسيقية
          </Text>
          <View style={styles.instrumentButtons}>
            {Object.values(InstrumentType).map((instrument) => (
              <Pressable
                key={instrument}
                style={[
                  styles.instrumentButton,
                  {
                    backgroundColor:
                      audioSettings.settings.instrument === instrument
                        ? colors.primary
                        : colors.border,
                  },
                ]}
                onPress={() => handleInstrumentChange(instrument)}
              >
                <Text
                  style={[
                    styles.instrumentButtonText,
                    {
                      color:
                        audioSettings.settings.instrument === instrument
                          ? colors.background
                          : colors.foreground,
                    },
                  ]}
                >
                  {instrument === InstrumentType.PIANO && "البيانو"}
                  {instrument === InstrumentType.ORGAN && "الأورج"}
                  {instrument === InstrumentType.DIGITAL_PIANO && "البيانو الرقمي"}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* التحكم بالصدى (Reverb) */}
        <View
          style={[
            styles.section,
            { borderColor: colors.border, backgroundColor: colors.surface },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            الصدى (Reverb): {Math.round(audioSettings.settings.reverb * 100)}%
          </Text>
          <View style={styles.sliderContainer}>
            <Pressable
              style={[styles.sliderButton, { backgroundColor: colors.primary }]}
              onPress={() =>
                handleReverbChange(
                  Math.max(0, audioSettings.settings.reverb - 0.1)
                )
              }
            >
              <Text style={[styles.sliderButtonText, { color: colors.background }]}>
                −
              </Text>
            </Pressable>
            <View
              style={[
                styles.sliderBar,
                {
                  backgroundColor: colors.primary,
                  width: audioSettings.settings.reverb * 200,
                },
              ]}
            />
            <Pressable
              style={[styles.sliderButton, { backgroundColor: colors.primary }]}
              onPress={() =>
                handleReverbChange(
                  Math.min(1, audioSettings.settings.reverb + 0.1)
                )
              }
            >
              <Text style={[styles.sliderButtonText, { color: colors.background }]}>
                +
              </Text>
            </Pressable>
          </View>
        </View>

        {/* التحكم بالاستمرار (Sustain) */}
        <View
          style={[
            styles.section,
            { borderColor: colors.border, backgroundColor: colors.surface },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            الاستمرار (Sustain): {Math.round(audioSettings.settings.sustain * 100)}%
          </Text>
          <View style={styles.sliderContainer}>
            <Pressable
              style={[styles.sliderButton, { backgroundColor: colors.primary }]}
              onPress={() =>
                handleSustainChange(
                  Math.max(0, audioSettings.settings.sustain - 0.1)
                )
              }
            >
              <Text style={[styles.sliderButtonText, { color: colors.background }]}>
                −
              </Text>
            </Pressable>
            <View
              style={[
                styles.sliderBar,
                {
                  backgroundColor: colors.primary,
                  width: audioSettings.settings.sustain * 200,
                },
              ]}
            />
            <Pressable
              style={[styles.sliderButton, { backgroundColor: colors.primary }]}
              onPress={() =>
                handleSustainChange(
                  Math.min(1, audioSettings.settings.sustain + 0.1)
                )
              }
            >
              <Text style={[styles.sliderButtonText, { color: colors.background }]}>
                +
              </Text>
            </Pressable>
          </View>
        </View>

        {/* المظهر (فاتح/داكن) */}
        <View
          style={[
            styles.section,
            { borderColor: colors.border, backgroundColor: colors.surface },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            المظهر
          </Text>
          <View style={styles.instrumentButtons}>
            {(["light", "dark"] as const).map((scheme) => (
              <Pressable
                key={scheme}
                style={[
                  styles.instrumentButton,
                  {
                    backgroundColor:
                      colorScheme === scheme ? colors.primary : colors.border,
                  },
                ]}
                onPress={() => setColorScheme(scheme)}
              >
                <Text
                  style={[
                    styles.instrumentButtonText,
                    {
                      color:
                        colorScheme === scheme ? colors.background : colors.foreground,
                    },
                  ]}
                >
                  {scheme === "light" ? "فاتح" : "داكن"}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* معلومات التطبيق */}
        <View
          style={[
            styles.section,
            { borderColor: colors.border, backgroundColor: colors.surface },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            معلومات التطبيق
          </Text>
          <Text style={[styles.infoText, { color: colors.muted }]}>
            Sudanese Organ v1.0.0
          </Text>
          <Text style={[styles.infoText, { color: colors.muted }]}>
            A professional music app for playing organ with interactive keyboard
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  backButton: {
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: "600",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    flex: 1,
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 16,
  },
  section: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
  },
  instrumentButtons: {
    flexDirection: "row",
    gap: 8,
  },
  instrumentButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderRadius: 8,
    alignItems: "center",
  },
  instrumentButtonText: {
    fontSize: 12,
    fontWeight: "600",
  },
  sliderContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  sliderButton: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  sliderButtonText: {
    fontSize: 20,
    fontWeight: "bold",
  },
  sliderBar: {
    height: 8,
    borderRadius: 4,
    flex: 1,
  },
  infoText: {
    fontSize: 14,
    lineHeight: 20,
  },
});
