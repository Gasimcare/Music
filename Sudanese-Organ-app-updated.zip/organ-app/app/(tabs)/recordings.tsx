import { useState, useCallback } from "react";
import { View, ScrollView, Text, Pressable, StyleSheet, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { RecordingSystem, RecordedMelody } from "@/lib/recording-system";

export default function RecordingsScreen() {
  const colors = useColors();
  const [recordingSystem] = useState(() => new RecordingSystem());
  const [isRecording, setIsRecording] = useState(false);
  const [savedMelodies, setSavedMelodies] = useState<RecordedMelody[]>([]);
  const [recordingTime, setRecordingTime] = useState(0);

  const handleStartRecording = useCallback(() => {
    recordingSystem.startRecording();
    setIsRecording(true);
    setRecordingTime(0);
  }, [recordingSystem]);

  const handleStopRecording = useCallback(() => {
    const melody = recordingSystem.stopRecording();
    setIsRecording(false);
    if (melody) {
      setSavedMelodies((prev) => [melody, ...prev]);
    }
  }, [recordingSystem]);

  const handleDeleteMelody = useCallback(
    (id: string) => {
      recordingSystem.deleteMelody(id);
      setSavedMelodies((prev) => prev.filter((m) => m.id !== id));
    },
    [recordingSystem]
  );

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, "0")}`;
  };

  const renderMelodyItem = ({ item }: { item: RecordedMelody }) => (
    <View style={[styles.melodyCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.melodyInfo}>
        <Text style={[styles.melodyName, { color: colors.foreground }]}>
          {item.name}
        </Text>
        <Text style={[styles.melodyDetails, { color: colors.muted }]}>
          {item.notes.length} نغمة • {formatTime(item.duration)}
        </Text>
      </View>
      <View style={styles.melodyActions}>
        <Pressable
          style={[styles.actionButton, { backgroundColor: colors.primary }]}
          onPress={() => {
            // تشغيل اللحن
          }}
        >
          <Text style={[styles.actionButtonText, { color: colors.background }]}>
            ▶
          </Text>
        </Pressable>
        <Pressable
          style={[styles.actionButton, { backgroundColor: colors.error }]}
          onPress={() => handleDeleteMelody(item.id)}
        >
          <Text style={[styles.actionButtonText, { color: colors.background }]}>
            ✕
          </Text>
        </Pressable>
      </View>
    </View>
  );

  return (
    <ScreenContainer className="flex-1 bg-background">
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.foreground }]}>
          التسجيلات
        </Text>
      </View>

      <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
        {/* قسم التسجيل */}
        <View
          style={[
            styles.recordingSection,
            { backgroundColor: colors.surface, borderColor: colors.border },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            {isRecording ? "جاري التسجيل..." : "ابدأ التسجيل"}
          </Text>

          {isRecording && (
            <Text style={[styles.recordingTime, { color: colors.primary }]}>
              {formatTime(recordingTime)}
            </Text>
          )}

          <View style={styles.recordingButtons}>
            {!isRecording ? (
              <Pressable
                style={[styles.recordButton, { backgroundColor: colors.primary }]}
                onPress={handleStartRecording}
              >
                <Text style={[styles.recordButtonText, { color: colors.background }]}>
                  ● ابدأ التسجيل
                </Text>
              </Pressable>
            ) : (
              <Pressable
                style={[styles.recordButton, { backgroundColor: colors.error }]}
                onPress={handleStopRecording}
              >
                <Text style={[styles.recordButtonText, { color: colors.background }]}>
                  ■ إيقاف التسجيل
                </Text>
              </Pressable>
            )}
          </View>
        </View>

        {/* قائمة التسجيلات المحفوظة */}
        <View>
          <Text style={[styles.sectionTitle, { color: colors.foreground, marginTop: 20 }]}>
            التسجيلات المحفوظة ({savedMelodies.length})
          </Text>

          {savedMelodies.length === 0 ? (
            <View style={[styles.emptyState, { backgroundColor: colors.surface }]}>
              <Text style={[styles.emptyStateText, { color: colors.muted }]}>
                لم تقم بحفظ أي تسجيلات بعد
              </Text>
              <Text style={[styles.emptyStateSubText, { color: colors.muted }]}>
                ابدأ بالتسجيل لحفظ ألحانك المفضلة
              </Text>
            </View>
          ) : (
            <FlatList
              scrollEnabled={false}
              data={savedMelodies}
              renderItem={renderMelodyItem}
              keyExtractor={(item) => item.id}
              ItemSeparatorComponent={() => (
                <View style={[styles.separator, { backgroundColor: colors.border }]} />
              )}
            />
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 16,
  },
  recordingSection: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
  },
  recordingTime: {
    fontSize: 32,
    fontWeight: "bold",
    textAlign: "center",
  },
  recordingButtons: {
    gap: 8,
  },
  recordButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: "center",
  },
  recordButtonText: {
    fontSize: 16,
    fontWeight: "600",
  },
  melodyCard: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  melodyInfo: {
    flex: 1,
    gap: 4,
  },
  melodyName: {
    fontSize: 14,
    fontWeight: "600",
  },
  melodyDetails: {
    fontSize: 12,
  },
  melodyActions: {
    flexDirection: "row",
    gap: 8,
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  actionButtonText: {
    fontSize: 18,
    fontWeight: "bold",
  },
  emptyState: {
    borderRadius: 8,
    padding: 24,
    alignItems: "center",
    gap: 8,
  },
  emptyStateText: {
    fontSize: 16,
    fontWeight: "600",
  },
  emptyStateSubText: {
    fontSize: 14,
  },
  separator: {
    height: 1,
    marginVertical: 8,
  },
});
